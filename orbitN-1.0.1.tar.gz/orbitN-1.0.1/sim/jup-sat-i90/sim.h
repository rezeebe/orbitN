/*==================== Input Section =========================*/

#define JJ 3      /* No. of Bodies incl. central mass      */

/* turn macros off (disable): add U in front of string     */
#define FASTDRIFT /* merge drift steps                     */
#define UPN       /* Post-Newton (requires FAST)           */
#define UJ2       /* Solar Quadrupole Moment               */
#define ULUNAR    /* Lunar: EMB quadrupole (Quinn91)       */

#define UCORR     /* Symplectic corrector ON/OFF           */
#define STAGE 6   /* Symplectic corrector stage: 2, 4, 6   */

#define KAHAN     /* compensated summation (requires FAST) */

/* FOR ACCURACY AND STORAGE USE STATE VECTORS X V !        */
#define UORB_XV   /* output state xv. else: orb elements   */
#define ANG_DEG   /* output angle units: deg. else: rad    */
#define ELM_MJ 1  /* 0/1 use M0 or M0+mj to calc elements  */

/* CPU info (log file). disable in case of warnings/errors */
#define CPUINFO   

/*============================================================*/
