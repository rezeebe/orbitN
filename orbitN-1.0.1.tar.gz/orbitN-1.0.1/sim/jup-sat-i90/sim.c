/*
  jup-sat-i90

  Simulate Jupiter + Saturn with Saturn's eccentricity = 0.95 
  and inclination = 90 deg. Also known as the two planet problem 
  (e.g., Levison & Duncan 2000; Wisdom 2015; Hernandez et al. 2022)

  Raising the stepsize from 3 to 4 days, increases max |(E-E0)/E0| 
  by an order of magnitude at the end of the run (10,000 y).
  
*/

/*==================== Input Section =========================*/

/* set time step (days), t0, tend (days), save interval (steps) */
/* Y2D = 365.25 (years -> days)                                 */
const double in_dt = 3.0; // =1 sstep=100 Sat. masses e-7 NaN??????????
double       in_t0 = 0.e3*Y2D;
double     in_tend = 1.e4*Y2D; // 1.e4 6.e0
const int in_sstep = 10037;

/*============================================================*/