/*
  jup-ast-2to1
  
  Simulate Jupiter-asteroid system close to 2:1 resonance. 
  Execute a series of orbitN simulations with different 
  asteroid inititial conditions (Murray & Dermott 1999,
  Chapter 8.9).  
  
*/

/*==================== Input Section =========================*/

/* set time step (days), t0, tend (days), save interval (steps) */
/* Y2D = 365.25 (years -> days)                                 */
const double in_dt = 20.0;
double       in_t0 = 0.e3*Y2D;
double     in_tend = 1.2e3*Y2D*1.0;
const int in_sstep = 36;

/*============================================================*/