/*
  solsys-DE441

  Simulate solar system with initial conditions from DE441
  (Planets + Pluto).
  
*/

/*==================== Input Section =========================*/

 /* set time step (days), t0, tend (days), save interval (steps) */
 /* Y2D = 365.25 (years -> days)                                 */
 const double in_dt = -2.;
 double       in_t0 =  0.e3*Y2D;
 double     in_tend = -1.e4*Y2D;
 const int in_sstep =  73050; // 73050 1039

/*============================================================*/