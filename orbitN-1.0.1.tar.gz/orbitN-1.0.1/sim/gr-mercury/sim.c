/*
  gr-mercury

  Simulate Mercury's perihelion advance due to General Relativity.

  The calculated difference in the argument of perihelion over
  1000 years is 0.119389 deg, or 42.98 arcsec per century.
  The theoretical value is 42.98 arcsec/c (Einstein, 1916).

*/

/*==================== Input Section =========================*/

/* set time step (days), t0, tend (days), save interval (steps) */
/* Y2D = 365.25 (years -> days)                                 */
const double in_dt = 2.0;
double       in_t0 = 0.e3*Y2D;
double     in_tend = 1.e3*Y2D;
const int in_sstep = 100;

/*============================================================*/