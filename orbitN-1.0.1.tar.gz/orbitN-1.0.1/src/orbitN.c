/***************************************************************

   orbitN VERSION: 1.0.1 (05/2025)
   file: orbitN.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2025 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___
   
   counters ii: timesteps
             j: bodies from 0 (central mass) to J
             k: 3D coordinates from 1 to 3 (0 not used = NAN) 

   updates:

   05/54/25 coords.c simplified fbary2body(). orbitN.h set BAR_2_BOD_SMP				 
   03/10/23 t0
   03/04/23

   TODO:

***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include "orbitN.h"
#include "utils.h"

#ifndef SIM /* default */
/*==================== Input Section =========================*/

 /* set time step (days), t0, tend (days), save interval (steps) */
 /* Y2D = 365.25 (years -> days)                                 */
 const double in_dt = -2.0;
 double       in_t0 =  0.e3*Y2D;
 double     in_tend = -1.e4*Y2D;
 const int in_sstep =  73050;

/*============================================================*/
#else /* SIM can be defined via Makefile: $ make SIM=1 */
 #include "../sim/sim.c"
#endif

/* No. of Bodies m[j] << m[0] (set JJ in orbitN.h) */
#define J (JJ-1)  

/* define integers for function calls */
#ifdef KAHAN
 const int khn = 1;
#else
 const int khn = 0;
#endif

/* Symplectic corrector stage: 2, 4, 6 (set in orbitN.h) */
const int stage = STAGE;

/* for basic constants defs see orbit.h  */
/* derivs are defined here and set const */
const double k2  = KGAUSS*KGAUSS;
const double c2  = (C_MS*D2S/AU)*(C_MS*D2S/AU); /* c^2 in GAUSS */
const double c2i = (AU/(C_MS*D2S))*(AU/(C_MS*D2S));

/* global memory dummies (declared 'extern' in external functions) */
double **x_,**v_,**x__,**v__;

/* wallclock time counters */
clock_t tick_start, tick_t, tick_end;
double wall_time;

/* exit flag (quit properly) handled by sig_handler() */
int stop = 0;

/* print progress: set fraction of integration time */
/* (may be modified by save interval)               */
#define FRAC_PRGS 0.1

/* define IDs of integration sequence */
#define INTG_SLOW    1
#define INTG_FAST    2
#define INTG_FAST_PN 3

/*============================================================*/
/*======================== set_intg_seq() ====================*/
/*============================================================*/
/* set integration sequence based on macros in orbitN.h       */
int set_intg_seq(FILE *fplog, int flag)
{
 FILE *fout = stdout; /* output to stdout */
 if(flag)
    fout = fplog;     /* output to integration log file */

 int fdr=0,pn=0,igs;
#ifdef FASTDRIFT
 fdr = 1; 
#endif
#ifdef PN
 pn = 1;
#endif

 if(fdr == 0){
    igs = INTG_SLOW;
    fprintf(fout,"@ Integrator  = SLOW.\n");
    fprintf(fout,"@ Post-Newton, J2, LUNAR, CORR, KAHAN unavailable.\n");    
 }

 if(fdr == 1 && pn == 0){
    igs = INTG_FAST;
    fprintf(fout,"@ Integrator   = FAST\n");
    fprintf(fout,"@ Post-Newton  = OFF \n");
 }

 if(fdr == 1 && pn == 1){
    igs = INTG_FAST_PN;
    fprintf(fout,"@ Integrator   = FAST\n");
    fprintf(fout,"@ Post-Newton  = ON  \n");
 }

#ifdef J2
 if(fdr != 0)   
 fprintf(fout,"@ Solar Quadrp = ON \n");
#else
 fprintf(fout,"@ Solar Quadrp = OFF\n");
#endif
   
#ifdef LUNAR
 if(fdr != 0)   
 fprintf(fout,"@ Lunar        = ON\n");
#else
 fprintf(fout,"@ Lunar        = OFF\n");
#endif

#ifdef CORR
 if(fdr != 0)   
 fprintf(fout,"@ Corrector    = ON\n");
#else
 fprintf(fout,"@ Corrector    = OFF\n");
#endif

#ifdef KAHAN
 if(fdr != 0)   
 fprintf(fout,"@ Kahan        = ON\n");
#else
 fprintf(fout,"@ Kahan        = OFF\n");
#endif

 printf("\n");

 return(igs);

}
/*============================================================*/
/*======================== set_intg_seq() END ================*/
/*============================================================*/

/*============================================================*/
/*======================== intg_slow() =======================*/
/*============================================================*/
/* No FASTDRIFT (slow), NO: KAHAN, PN, J2, LUNAR, CORR !!!                      
   +inefficient conversions inert2jac <=> jac2inert           */

void intg_slow( \
      double **x, double **v, double **dx, double **dv, double **xb,
      double **vb, double **vj, double **cx, double **cv, double **xd,
      double **vd, double dt, const double t0, const double tend,
      const int sstep, struct masses mm, double erg0, double *ergfin,
      double *lv0, double l0, const double k2, const double c2,
      const int jmax, const int khn, FILE **fporbj, FILE *fperg,
      FILE *fplog)
{
 UNUSED(vj),UNUSED(cx),UNUSED(cv),UNUSED(xd),UNUSED(vd),UNUSED(jmax),
 UNUSED(khn);

 double t=t0,tt=tend-t0;
 double erg=0.,lv[3+1];
 /* total steps and progress */
 const unsigned long long \
       nstep = (unsigned long long)(fabs(tt/dt)),
          np = (unsigned long long)(fabs(tt*FRAC_PRGS/dt));
 unsigned long long ii; /* ii, j, k count timesteps, body, xyz */
 /* init save & progress counter */
 int is=0;
 unsigned long long ip=0;

#ifdef LOAD_SVE
 /* load saved coords */
 fload_sve(x,v,cx,cv,J);
#endif

 /******************** for loop ***********************/	
 for(ii=1;ii<=nstep;ii++){
  t = t0 + ii*dt; /* time for save/final */
  /* inertia to Jacobi */
  finert2jac(x,v,x,v,mm.m,mm.msumj,J);
  /* drift 1/2 */
  fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
  /* get bary => xb, vb. then kick */
  fjac2inert(xb,vb,x,v,mm.m,mm.msumj,J);
  fkick(x,v,dx,dv,dt*1.0,xb,mm.m,mm.msumj,k2,c2i,J,khn);
  /* drift 1/2 */
  fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
  /* Jacobi to inertia */
  fjac2inert(x,v,x,v,mm.m,mm.msumj,J);
  is += 1; ip += 1;
  /* write to file ? */
  if(is >= sstep){
    if(ip >= np){ /* print progress */
      printf("@ t = %.2f (%.1f%%)\n",t,(t-t0)*100./tt);
      fflush(stdout);
      ip = 0;
    }
    /* write wallclock time */
    tick_t  = clock();
    fwall_time(tick_start,tick_t,t,t0,tend,ii,1,fplog);
    /* write energy, etc. */
    erg = fenergy(x,v,mm,k2,c2,J,0);
    fangm(lv,x,v,mm,k2,c2,J,0);
    fwrtOrb(fporbj,t,x,v,mm.m,mm.msumj,mm.eta,J,1);
    fwrtErgAng(fperg,t,erg,erg0,lv,lv0,l0);
    is = 0;
  }
  if(ii == nstep || stop){
     /* write wallclock time */
     tick_t  = clock();
     fwall_time(tick_start,tick_t,t,t0,tend,ii,0,fplog);
     break;
  }
 }
 /******************** for loop END *******************/	

#ifdef SAVE_FIN
 /* save final coords for load/restart */
 fsave_fin(x,v,cx,cv,J);
#endif

 /* Energy (final save) */
 *ergfin = erg;

}
/*============================================================*/
/*======================== intg_slow() END ===================*/
/*============================================================*/

/*============================================================*/
/*======================== intg_fast() =======================*/
/*============================================================*/
void intg_fast( \
      double **x, double **v, double **dx, double **dv, double **xb,
      double **vb, double **vj, double **cx, double **cv, double **xd,
      double **vd, double dt, const double t0, const double tend,
      const int sstep, struct masses mm, double erg0, double *ergfin,
      double *lv0, double l0, const double k2, const double c2,
      const int jmax, const int khn, FILE **fporbj, FILE *fperg,
      FILE *fplog)
{
 UNUSED(vb),UNUSED(vj),UNUSED(jmax);
 double t=t0,tt=tend-t0;
 double erg=0.,lv[3+1];
 /* total steps and progress */
 const unsigned long long \
       nstep = (unsigned long long)(fabs(tt/dt)),
          np = (unsigned long long)(fabs(tt*FRAC_PRGS/dt));
 unsigned long long ii; /* ii, j, k count timesteps, body, xyz */
 /* init save & progress counter */
 int is=0;
 unsigned long long ip=0;
 /* did save flag for t>0. sync: take two 1/2 kep steps */ 
 int savedflag_t=0;

 /* first 1/2 step for fast drift */
 /* inertia to Jacobi */
 finert2jac(x,v,x,v,mm.m,mm.msumj,J);
#ifdef CORR
 /* corrector */
 fcorr(x,v,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,0,stage);
#endif
#ifdef LOAD_SVE
 /* load saved coords */
 fload_sve(x,v,cx,cv,J);
#endif
 /* drift 1/2 */
 fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
 fkahan(x,v,cx,cv,dx,dv,J,khn);

 /******************** for loop ***********************/	
 for(ii=1;ii<=nstep;ii++){
  t = t0 + ii*dt; /* time for save/final */
#if (JJ > 1) // 2 or 1(PN!) ??? 
  fkick(x,v,dx,dv,dt*1.0,xb,mm.m,mm.msumj,k2,c2i,J,khn);
  fkahan_v(v,cv,dv,J,khn);
#endif
  is += 1; ip += 1;
  /* write to file ? (after 1/2 drift) */
  if(is >= sstep){
    if(ip >= np){ /* print progress */
      printf("@ t = %.2f (%.1f%%)\n",t,(t-t0)*100./tt);
      fflush(stdout);
      ip = 0;
    }
    /* write wallclock time */
    tick_t  = clock();
    fwall_time(tick_start,tick_t,t,t0,tend,ii,1,fplog);
    /* drift 1/2 before save */
    fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
    fkahan(x,v,cx,cv,dx,dv,J,khn);
    /* use dummies for save: copy xv */
    fcopyxv(xd,vd,x,v,J);
#ifdef CORR
    /* corrector: inverse */
    fcorr(xd,vd,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,1,stage);
#endif
    /* Jacobi to inertia (use dummies for save) */
    fjac2inert(xd,vd,xd,vd,mm.m,mm.msumj,J);
    /* save */
    erg = fenergy(xd,vd,mm,k2,c2,J,0);
    fangm(lv,xd,vd,mm,k2,c2,J,0);
    fwrtOrb(fporbj,t,xd,vd,mm.m,mm.msumj,mm.eta,J,1);
    fwrtErgAng(fperg,t,erg,erg0,lv,lv0,l0);
    savedflag_t = 1;
    is = 0;
  }
  if(ii == nstep || stop){
   if(savedflag_t == 0){  
     /* drift 1/2 final step */
     fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
     fkahan(x,v,cx,cv,dx,dv,J,khn);
     /* write wallclock time */
     tick_t  = clock();
     fwall_time(tick_start,tick_t,t,t0,tend,ii,0,fplog);
   }
   break;
  }
  if(savedflag_t){
     /* drift 1/2 after save */
     fgdrift(x,v,dx,dv,dt*0.5,mm.eta,c2i,J,khn);
     fkahan(x,v,cx,cv,dx,dv,J,khn);
     savedflag_t = 0;
  } else{
     /* drift 1/1 (no save) */
     fgdrift(x,v,dx,dv,dt*1.0,mm.eta,c2i,J,khn);
     fkahan(x,v,cx,cv,dx,dv,J,khn);
  }
 }
 /******************** for loop END *******************/	

#ifdef SAVE_FIN
 /* save final coords & bits for load/restart */
 fsave_fin(x,v,cx,cv,J);
#endif

 /* final conversions for fast drift */

#ifdef CORR
 /* corrector: inverse */
 fcorr(x,v,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,1,stage);
#endif

 /* Jacobi to inertia */
 fjac2inert(x,v,x,v,mm.m,mm.msumj,J);

 /* Energy (final save) */
 *ergfin = erg;

}
/*============================================================*/
/*======================== intg_fast() END ===================*/
/*============================================================*/

/*============================================================*/
/*======================== intg_fast_pn() ====================*/
/*============================================================*/
void intg_fast_pn( \
      double **x, double **v, double **dx, double **dv, double **xb,
      double **vb, double **vj, double **cx, double **cv, double **xd,
      double **vd, double dt, const double t0, const double tend,
      const int sstep, struct masses mm, double erg0, double *ergfin,
      double *lv0, double l0, const double k2, const double c2,
      const int jmax, const int khn, FILE **fporbj, FILE *fperg,
      FILE *fplog)
{
 UNUSED(vb),UNUSED(jmax);
 double t=t0,tt=tend-t0;
 double erg=0.,lv[3+1];
 /* total steps and progress */
 const unsigned long long \
       nstep = (unsigned long long)(fabs(tt/dt)),
          np = (unsigned long long)(fabs(tt*FRAC_PRGS/dt));
 unsigned long long ii; /* ii, j, k count timesteps, body, xyz */
 /* init save & progress counter */
 int is=0;
 unsigned long long ip=0;
 /* did save flag for t>0. sync: take two 1/2 kep steps */ 
 int savedflag_t=0;

 /* macro: combine PN gamma half steps and drift */
#define PNGAM_DRFT(h)                     \
 {                                        \
   /* PN: gamma half */                   \
   fpn_gam_half(x,v,dx,h,c2i,J);          \
   fkahan_x(x,cx,dx,J,khn);               \
   /* drift */                            \
   fgdrift(x,v,dx,dv,h,mm.eta,c2i,J,khn); \
   fkahan(x,v,cx,cv,dx,dv,J,khn);         \
   /* PN: gamma half */                   \
   fpn_gam_half(x,v,dx,h,c2i,J);          \
   fkahan_x(x,cx,dx,J,khn);               \
 }

 /* first 1/2 step for fast drift */
 /* inertia to Jacobi */
 finert2jac(x,v,x,v,mm.m,mm.msumj,J);
 /* convert v-jac to v-pseudo */
 fjac2pseudo_v(v,x,v,mm,k2,c2,J);
#ifdef CORR
 /* corrector */
 fcorr(x,v,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,0,stage);
#endif
#ifdef LOAD_SVE
 /* load saved coords */
 fload_sve(x,v,cx,cv,J);
#endif

 /* PN gamma half + drift */
 PNGAM_DRFT(dt*0.5);

 /******************** for loop ***********************/	
 for(ii=1;ii<=nstep;ii++){
  t = t0 + ii*dt; /* time for save/final */
#if (JJ > 1) // 2 or 1(PN!) ???
  fkick(x,v,dx,dv,dt*1.0,xb,mm.m,mm.msumj,k2,c2i,J,khn);
  fkahan_v(v,cv,dv,J,khn);
#endif
  is += 1; ip += 1;
  /* write to file ? (after 1/2 drift) */
  if(is >= sstep){
    if(ip >= np){ /* print progress */
      printf("@ t = %.2f (%.1f%%)\n",t,(t-t0)*100./tt);
      fflush(stdout);
      ip = 0;
    }
    /* write wallclock time */
    tick_t  = clock();
    fwall_time(tick_start,tick_t,t,t0,tend,ii,1,fplog);
    /* drift 1/2 before save */
    /* PN gamma half + drift */
    PNGAM_DRFT(dt*0.5);
    /* use dummies for save: copy xv */
    fcopyxv(xd,vd,x,v,J);
#ifdef CORR
    /* corrector: inverse */
    fcorr(xd,vd,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,1,stage);
#endif
    /* convert v-pseudo to v-jac for save */
    fpseudo2jac_v(vj,xd,vd,mm,k2,c2,J);
    /* Jacobi to inertia */
    fjac2inert(xd,vd,xd,vj,mm.m,mm.msumj,J);
    /* save */
    erg = fenergy(xd,vd,mm,k2,c2,J,0);
    fangm(lv,xd,vd,mm,k2,c2,J,0);
    fwrtOrb(fporbj,t,xd,vd,mm.m,mm.msumj,mm.eta,J,1);
    fwrtErgAng(fperg,t,erg,erg0,lv,lv0,l0);
    savedflag_t = 1;
    is = 0;
  } /* save END */
  if(ii == nstep || stop){
   if(savedflag_t == 0){
     /* drift 1/2 final step */
     /* PN gamma half + drift */
     PNGAM_DRFT(dt*0.5);
   }
   /* write wallclock time */
   tick_t  = clock();
   fwall_time(tick_start,tick_t,t,t0,tend,ii,0,fplog);
   break;
  } /* nstep END */
  if(savedflag_t){
     /* drift 1/2 after save */
     /* PN gamma half + drift */
     PNGAM_DRFT(dt*0.5);
     savedflag_t = 0;
  } else{
     /* drift 1/1 (no save) */
     /* PN gamma half + drift */
     PNGAM_DRFT(dt*1.0);
  }
 }
 /******************** for loop END *******************/	

#ifdef SAVE_FIN
 /* save final coords & bits for load/restart */
 fsave_fin(x,v,cx,cv,J);
#endif

 /* final conversions for fast drift */

#ifdef CORR
 /* corrector: inverse */
 fcorr(x,v,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,J,1,stage);
#endif

 /* convert v-pseudo to v-jac */
 fpseudo2jac_v(v,x,v,mm,k2,c2,J);

 /* Jacobi to inertia */
 fjac2inert(x,v,x,v,mm.m,mm.msumj,J);

 /* Energy (final save) */
 *ergfin = erg;

}
/*============================================================*/
/*======================== intg_fast_pn() END ================*/
/*============================================================*/

/*============================================================*/
/*======================== sig_handler() =====================*/
/*============================================================*/
/*
  exit properly on Ctrl+C and kill
*/
void sig_handler(int signo)
{
 if(signo == SIGINT){
    printf("\n+++ Received SIGINT. Saving, exiting.\n");
    stop = 1;
 }
 if(signo == SIGTERM){
    printf("\n+++ Received SIGTERM. Saving, exiting.\n");
    stop = 1;
 }

}
/*============================================================*/
/*======================== sig_handler() END =================*/
/*============================================================*/

/*============================================================*/
/*======================== driver() ==========================*/
/*============================================================*/
/*
 driver routine
 */
void driver(int argc, char **argv)
{
 /* ii, j, k count timesteps, body, xyz */
 int j,k;
 int intg_seq;
 double erg,erg0,lv[3+1],lv0[3+1],l0;
 struct masses mm;
 FILE *fporbj[J+1]; FILE *fperg=NULL; FILE *fplog=NULL;
 char fnorbj[BUFSIZ];
 int jstart = 0; /* output state xv: include index 0 */
#ifndef ORB_XV
 jstart = 1;     /* output elements: exclude index 0 */
#endif

 UNUSED(argc); UNUSED(argv);

 /* exit properly on Ctrl+C and kill */
 if(signal(SIGINT,sig_handler) == SIG_ERR)
    printf("\n@ Can't catch SIGINT\n");
 if(signal(SIGTERM,sig_handler) == SIG_ERR)
    printf("\n@ Can't catch SIGTERM\n");

 printf("\n");
 printf("*** orbitN comes with ABSOLUTELY NO WARRANTY ***\n");		 
 printf("*** Use at your own risk. DO NOT DISTRIBUTE  ***\n\n");
 printf("@ This is %s\n",VER);
 printf("@ Richard E. Zeebe. orbitN.code@gmail.com\n");

 /* set time step, t0, tend, save interval (steps) */
 const double dt = in_dt;
 double       t0 = in_t0; 
 double     tend = in_tend;
 const int sstep = in_sstep;

 /* read initial coordinates. set dir & file */
 double *m, **x0, **v0;
 char dir[BUFSIZ],foo[BUFSIZ];
 /* include index zero = central mass */
 m  = dvector(0,J);	
 x0 = dmatrix(0,J,1,3);
 v0 = dmatrix(0,J,1,3);	
 strcpy(dir,".");
 //strcpy(dir,"./coords");
 strcpy(foo,"orbitN-coord.inp");
 //strcpy(foo,"orbitN-coord.DE441.inp");
 freadcoords(dir,foo,J,m,x0,v0);

#ifdef LUNAR
 if(J < 3)
    ferrx("LUNAR option requires J >= 3, index 3 = Earth");
#endif

 /* initialize various */
 double **x,**v,**dx,**dv,**xb,**vb,**vj,**cx, **cv;
 double **xd,**vd;
 x  = dmatrix(0,J,1,3);
 v  = dmatrix(0,J,1,3);
 dx = dmatrix(0,J,1,3);
 dv = dmatrix(0,J,1,3);
 xb = dmatrix(0,J,1,3);
 vb = dmatrix(0,J,1,3);
 vj = dmatrix(0,J,1,3);
 cx = dmatrix(0,J,1,3);
 cv = dmatrix(0,J,1,3);
 /* dummies */
 xd = dmatrix(0,J,1,3);
 vd = dmatrix(0,J,1,3);
 x_  = dmatrix(0,J,1,3);
 v_  = dmatrix(0,J,1,3);
 x__ = dmatrix(0,J,1,3);
 v__ = dmatrix(0,J,1,3);

 for(j=0;j<=J;j++){
  for(k=1;k<=3;k++){
      dx[j][k] = 0.;
      dv[j][k] = 0.;
      cx[j][k] = 0.;
      cv[j][k] = 0.;
  }
 }

 /* Input body coords: central mass */
 m[0] = 1.0;
 for(k=1;k<=3;k++){
     x0[0][k] = 0.;
     v0[0][k] = 0.;
 }

 /* open orbit files for bodies */
 for(j=jstart;j<=J;j++){
    sprintf(fnorbj,"orbitN-%d.dat",j);
    fporbj[j] = fopen(fnorbj,"a");
 }
 /* open energy & log file */
 char *fnerg="orbitN-erg.dat";
 char *fnlog="orbitN.log";
 fopenwrt(&fperg,fnerg,&fplog,fnlog);
 
 /* Jacobi mass, sum, eta */
 double *mj, *msumj, *eta;
 mj    = dvector(0,J);
 msumj = dvector(0,J);
 eta   = dvector(0,J);
 fjacmass(mj,msumj,eta,m,&mm,k2,J);

 /* convert to barycentrics */
 fbody2bary(x,v,x0,v0,m,J);

 /* Energy t0. Caution: at each step would take 60% of drift CPU */
 erg0 = fenergy(x,v,mm,k2,c2,J,0);
 printf("\n@ E0 = %22.15e\n",erg0);
 erg = erg0;

 /* Angular Momentum t0 */
 fangm(lv0,x,v,mm,k2,c2,J,0);
 l0 = NORM(lv0);
 printf("@ L0 = %22.15e %22.15e %22.15e\n",lv0[1],lv0[2],lv0[3]);
 vsclr(lv,1.0,lv0,3); 

 /* write start values to file */
 int coordflag = 1; /* coords = bary */ 
#ifdef LOAD_SVE
 coordflag = 2;     /* coords = jac */
 fload_conv(&erg,lv,x,v,dx,dv,xb,dt,mm,k2,c2i,c2,J,1,stage);
#endif
 if(!RESTART){
    fwrtOrb(fporbj,t0,x,v,m,msumj,eta,J,coordflag);
    fwrtErgAng(fperg,t0,erg,erg0,lv,lv0,l0);
 }

 /* write parameters to integration log file */
 fwrtLog(fplog,x0,v0,dt,t0,tend,m,sstep,erg0,lv0,k2,c2,J,0);

 /*****************************************************/
 /****************** main integration *****************/
 /*****************************************************/

 /* set integration sequence based on macros */
 intg_seq = set_intg_seq(fplog,0);
 /* start clock. 
    Note: intermediatate and final clock calls in intg_x */ 
 tick_start = clock();
 printf("@ Starting integration.\n\n");
 fflush(stdout);
      
 switch(intg_seq)
 {
  /*===================================================*/
  case INTG_SLOW:
     intg_slow( \
              x,v,dx,dv,xb,vb,vj,cx,cv,xd,vd,dt,t0,tend,sstep,mm, \
              erg0,&erg,lv0,l0,k2,c2,J,khn,fporbj,fperg,fplog);
     break;
  /*===================================================*/
  case INTG_FAST:
     intg_fast( \
              x,v,dx,dv,xb,vb,vj,cx,cv,xd,vd,dt,t0,tend,sstep,mm, \
              erg0,&erg,lv0,l0,k2,c2,J,khn,fporbj,fperg,fplog);
     break;
  /*===================================================*/
  case INTG_FAST_PN:
     intg_fast_pn( \
              x,v,dx,dv,xb,vb,vj,cx,cv,xd,vd,dt,t0,tend,sstep,mm, \
              erg0,&erg,lv0,l0,k2,c2,J,khn,fporbj,fperg,fplog);
     break;
  /*===================================================*/
  default:
     intg_fast( \
              x,v,dx,dv,xb,vb,vj,cx,cv,xd,vd,dt,t0,tend,sstep,mm, \
              erg0,&erg,lv0,l0,k2,c2,J,khn,fporbj,fperg,fplog);
 }
 
 if(!stop){
    printf("\n@ Integrator Done.\n");
    fprintf(fplog,"@ Integrator Done.\n");
 } else {
    printf("\n@ Integrator Stopped.\n");
    fprintf(fplog,"@ Integrator Stopped.\n");
 }

 /*****************************************************/
 /****************** main integration END *************/
 /*****************************************************/

 /* Energy (final save) */
 printf("\n@  E = %22.15e",erg);
 printf("\n@ dE = %22.15e\n\n",(erg-erg0)/erg0);	

 /* convert to body for output ? */
 fbary2body(x,v,x,v,m,J);

#define UCHECKXV
#ifdef CHECKXV
 int jx = (int)fmin(J,3);
 for(j=0;j<=jx;j++)
    printf("%.15f %.15f %.15f\n",x[j][1],x[j][2],x[j][3]);
 printf("\n");	
 for(j=0;j<=jx;j++)
    printf("%.15f %.15f %.15f\n",v[j][1],v[j][2],v[j][3]);
#endif

 /* write final items to integration log file */
 fwrtLog(fplog,x0,v0,dt,t0,tend,m,sstep,erg0,lv0,k2,c2,J,1);

 /* close files */
 for(j=jstart;j<=J;j++)
     fclose(fporbj[j]);
 fclose(fperg);
 fclose(fplog);

 if(!stop)
  printf("\n@ orbitN Done.\n\n");
 else
  printf("\n@ orbitN Stopped.\n\n");

 /* free memory */
 free_dvector(m,0,J);
 free_dmatrix(x,0,J,1,3);
 free_dmatrix(v,0,J,1,3);
 free_dmatrix(dx,0,J,1,3);
 free_dmatrix(dv,0,J,1,3);
 free_dmatrix(xb,0,J,1,3);
 free_dmatrix(vb,0,J,1,3);
 free_dmatrix(vj,0,J,1,3);
 free_dmatrix(cx,0,J,1,3);
 free_dmatrix(cv,0,J,1,3);
 free_dmatrix(xd,0,J,1,3);
 free_dmatrix(vd,0,J,1,3);
 free_dmatrix(x0,0,J,1,3);
 free_dmatrix(v0,0,J,1,3);
 free_dvector(mj,0,J);
 free_dvector(msumj,0,J);
 free_dvector(eta,0,J);
 free_dmatrix(x_,0,J,1,3);
 free_dmatrix(v_,0,J,1,3);
 free_dmatrix(x__,0,J,1,3);
 free_dmatrix(v__,0,J,1,3);
}
/*============================================================*/
/*==================== driver() END ==========================*/
/*============================================================*/

/*============================================================*/
/*==================== int main() ============================*/
/*============================================================*/
int main(int argc, char **argv)
{

 driver(argc,argv);

 return(0);
}
/*==================== int main END ==========================*/
