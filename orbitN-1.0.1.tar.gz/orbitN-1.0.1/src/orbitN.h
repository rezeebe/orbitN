/***************************************************************

   orbitN VERSION: 1.0.1 (05/2025)
   file: orbitN.h

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2025 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___
   updates:

   05/54/25 coords.c simplified fbary2body(). set BAR_2_BOD_SMP below
   03/04/23

   TODO:

***************************************************************/
#define VER "orbitN VERSION: 1.0.1 (05/2025)"

#include <math.h>
#include <time.h>

#ifndef SIM /* default */
/*==================== Input Section =========================*/

#define JJ 10     /* No. of Bodies incl. central mass      */

/* turn macros off (disable): add U in front of string     */
#define FASTDRIFT /* merge drift steps                     */
#define PN        /* Post-Newton (requires FAST)           */
#define UJ2        /* Solar Quadrupole Moment               */
#define ULUNAR     /* Lunar: EMB quadrupole (Quinn91)       */

#define CORR      /* Symplectic corrector ON/OFF           */
#define STAGE 6   /* Symplectic corrector stage: 2, 4, 6   */

#define KAHAN     /* compensated summation (requires FAST) */

/* FOR ACCURACY AND STORAGE USE STATE VECTORS X V !        */
#define ORB_XV    /* output state xv. else: orb elements   */
#define ANG_DEG   /* output angle units: deg. else: rad    */
#define ELM_MJ 1  /* 0/1 use M0 or M0+mj to calc elements  */

/* CPU info (log file). disable in case of warnings/errors */
#define CPUINFO   

/*============================================================*/
#else /* SIM can be defined via Makefile: $ make SIM=1 */
 #include "../sim/sim.h"
#endif

#define NMAX 100 /* allocate max # of bodies */
#define CDIM 3+1 /* 3D space + 1 for [0] (C) */

#define UWARN     /* print all warnings */

/* avoid compiler warnigs: unused parameters */
#define UNUSED(_z_) (void)(_z_)

/* 3D vector norm & square */
//#define NORM(x) sqrt(x[1]*x[1] + x[2]*x[2] + x[3]*x[3])
//#define  SQR(x)     (x[1]*x[1] + x[2]*x[2] + x[3]*x[3])
#define NORM(_z_) sqrt(_z_[1]*_z_[1]+_z_[2]*_z_[2]+_z_[3]*_z_[3])
#define  SQR(_z_)     (_z_[1]*_z_[1]+_z_[2]*_z_[2]+_z_[3]*_z_[3])

#ifndef NAN
 #define NAN (sqrt(-1))
#endif

/* basic constants */
#define KGAUSS 0.01720209895
#define AU     1.495978707e11 /* m    */
#define C_MS   299792458.     /* m/s  */

/* Solar Quadrupole parameters (oblateness) */
#define OBLTJ2 2.2e-7   /* Solar J2 value  */
#define OBLTR  0.00465  /* Solar J2 radius */

/* Solar Quadrupole constant */
#define AJ2C 0.5*KGAUSS*KGAUSS*OBLTJ2*OBLTR*OBLTR

/* Lunar factor (Quinn91, Varadi03) */
#define F_LUNAR 0.8525

/* time & angle */
#define D2S  (3600.*24.)
#define Y2D   365.25
#define PI    3.14159265358979323846
#define R2D  (180./PI)      /* radians to deg */

#define BAR_2_BOD_SMP /* use simplified fbary2body() */

struct masses {
   double m[NMAX];     /* masses        */
   double mj[NMAX];    /* Jacobi masses */
   double msumj[NMAX]; /* sum to mass j */
   double eta[NMAX];   /* GMj Jacobi    */
} ;

struct elements {
   double a;   /* semimajor axis */
   double e;   /* eccentricity   */
   double i;   /* inclination    */
   double om;  /* ArgPerihelion  */
   double oom; /* LongAscNode    */
   double vpi; /* LongPerihelion */
   double mn;  /* mean anomaly   */
} ;

#ifdef __DBL_EPSILON__
 #define DBL_EPS __DBL_EPSILON__
#else
 #define DBL_EPS 2.22044604925031308085e-16
#endif

/* save/load final coords & bits (int_x) for new run/restart ? */
#define SAVE_FIN
#define ULOAD_SVE
#define RESTART 0 /* 0/1 write/don't write start values */
#define SAVEFILE "orbitN-final.sve"

/* slow drift: disable options if set in input (unavailable) */
#ifndef FASTDRIFT
 #undef PN
 #undef J2
 #undef LUNAR
 #undef CORR
 #undef KAHAN 
#endif

/* orbitN.c */
int set_intg_seq(FILE *fplog, int flag);
/* coords.c */
void fjacmass(double *mj, double *msumj, double *eta, double *m,
              struct masses *mm, const double k2, const int jmax);
void fbody2bary(double **xr, double **vr, double **x,
                double **v, double *m, const int jmax);
void fbary2body(double **x, double **v, double **xr,
                double **vr, double *m, const int jmax);
void finert2jac(double **xj, double **vj, double **x, double **v, 
                double *m, double *msumj, const int jmax);
/* aa[][CDIM] initialized/used only in subroutines: */
void finert2jac_a(double aa[][CDIM], const double *m,
                  const double *msumj, const int jmax);
void fjac2inert(double **xi, double **vi, double **x, double **v, 
                double *m, double *msumj, const int jmax);
void fjac2inert_x(double **xi, double **x, double *m,
                  double *msumj, const int jmax);
//#ifdef PN
void fjac2pseudo_v(double **vp, double **x, double **v,
                   struct masses m, const double k2,
                   const double c2, const int jmax);
void fpseudo2jac_v(double **vj, double **xj, double **vp,
                   struct masses m, const double k2,
                   const double c2, const int jmax);                 
//#endif                 
/* operator.c */
void fgdrift(double **xx, double **vv, double **dxx, double **dvv,
             double dt, double *eta, const double c2i, const int jmax,
             int khn);
void fkick(double **xx, double **vv, double **dxx, double **dvv,
           double dt, double **xxb, double *m, double *msumj,
           const double k2, const double c2i, const int jmax, 
           int khn);
void fkepstmpff(double *gg, double *nri, const double nr0, const double u,
                  const double zeta, const double etaj,
                  const double dt, const double beta, const double s0);
void fgkstumpff(double *cc, double beta, double s);                  
double fparm_lunar(double t, const double k2);
void fcorr(double **xx, double **vv, double **dxx, double **dvv,
           double **xb, double dt, double *m, double *msumj,
           double *eta, const double k2, const double c2i,
           const int jmax, int inv, const int stage);
//#ifdef PN
void fpn_gam_half(double **xx, double **vv, double **dxx,
                  double dt, const double c2i, const int jmax);
//#endif
void fkahan(double **xx, double **vv, double **cx, double **cv,
            double **dxx, double **dvv, const int jmax, int flag);
void fkahan_x(double **xx, double **cx, double **dxx, const int jmax, int flag);
void fkahan_v(double **vv, double **cv, double **dvv, const int jmax, int flag);
/* energyangm.c */
double fenergy(double **xx, double **vv, struct masses mm,
               const double k2, const double c2, const int jmax,
               int flag);
double ferg_lunar(double **xx, double *m, const double k2);
void fangm(double *lv, double **xx, double **vv, struct masses mm,
           const double k2, const double c2, const int jmax, int flag);
/* readwrite.c */
void freadcoords(char *dir, char *foo, int nreq, double *m,
                 double **x, double **v);
void fxv2elm(struct elements *elm, double *x, double *v, 
             double eta);
void fopenwrt(FILE **fperg, char *fnerg, FILE **fplog, char *fnlog);
void fwrtOrbxyz(FILE **fporbj, double t, double **x, double **v, double *m, 
                double *msumj, const int jmax, int flag);
void fwrtOrbelm(FILE **fporbj, double t, double **x, double **v, 
                double *m, double *msumj, double *eta, const int jmax, 
                int flag); 
void fwrtOrb(FILE **fporbj, double t, double **x, double **v, 
             double *m, double *msumj, double *eta, const int jmax, 
             int flag);         
void fwall_time(clock_t tick0, clock_t tick, double t, double t0,
                double tmax, unsigned long long ii, int saveflag,
                FILE *fplog);
void fwrtErgAng(FILE *fid, double t, double erg, double erg0,
                double *lv, double *lv0, double l0);
void fwrtLog(FILE *fplog, double **x0, double **v0, double dt,
             double t0, double tmax, double *m, const int sstep,
             double erg0, double *lv0, const double k2,
             const double c2, const int jmax, int flag);
double fwraptopi(double x);
void fsave_fin(double **xx, double **vv, double **cx, double **cv, const int jmax);
void fload_sve(double **xx, double **vv, double **cx, double **cv, const int jmax);
void fload_conv(double *erg, double *lv,
                double **x, double **v, double **dx, double **dv,
                double **xb, double dt, struct masses mm,
                const double k2, const double c2i, const double c2,
                const int jmax, int inv, const int stage);

