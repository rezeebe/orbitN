/***************************************************************

   orbitN VERSION: 1.0.1 (05/2025)
   file: readwrite.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2025 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   updates:

   05/06/25 fcheck() initialize jm=-1	   
   05/17/23 Output Keplerian elements: Case e>=1
   05/07/23 ei_case om, nu: acos -> acos_r
   03/11/23 t0, time output format -> %.15g.
            fwrtLog() timing info updated
   03/04/23

   TODO:
   pass *fnlog to fwrtLog()
   add fopenwrt() for orbit body files

***************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "orbitN.h"
#include "utils.h"

//#define NMAX 100 /* allocate max #bodies, see orbitN.h */
#define NVAL 7    /* m+x+v values to read */ 

/*============================================================*/
/*===================== freadcoords() ========================*/
/*============================================================*/
/*
  variables to read: m: mass, x: position, v: velocity 
*/
void freadcoords(char *dir, char *foo, int nreq, double *m, 
                 double **x, double **v)
{
 int i,k,l,imax,kmax;
 double **y;
 char *fpstr=dir,mssg[BUFSIZ],line[BUFSIZ];
 char *pch,*eptr;	
 FILE *fp;

 y = dmatrix(1,NMAX,1,NVAL);
	
 /* open coordinate file */
 strcat(fpstr,"/");
 strcat(fpstr,foo);
 fp = fopen(fpstr,"r");
 if(fp == NULL){ 
    sprintf(mssg,"freadcoords(): Can't open coordinate file: '%s'",fpstr);
	ferrx(mssg);
 } 
 else{
    printf("\n@ Reading coordinate file: '%s'\n",fpstr);
 }

 /* read line-by-line, extract vars m, x, v   */
 /* counters: i = bodies, k = vals, l = lines */
 i = k = l = 0;
 i++;
 while(fgets(line, sizeof(line), fp) != NULL){
  l++;
  /* ignore lines including "#" */
  if(!strstr(line,"#")){
   //printf("%s",line);
   /* split into tokens */
   pch = strtok(line," \t\r\n\v\f");
   while(pch != NULL){
     //printf("s= %s\n",pch);
     /* strings to ignore */
     if(!strstr(pch,"\\") && !strstr(pch,"\t")){
        k++;
        /* convert string to double */
        y[i][k] = strtod(pch,&eptr);
        //printf("%.17E %d %d\n",y[i][k],i,k);
#ifdef WARN		 
        if(y[i][k] == 0.0){
          sprintf(mssg,"freadcoords(): Warning reading coordinates '%s'",fpstr);			
          printf("i k l %d %d %d\n",i,k,l);
          printf("%.17E\n",y[i][k]);
          printf("\n+++ Coord input file: Some x0 or v0 are zero.\n");				
          fwarn(mssg);
        }
#endif		 
        if(k == NVAL){ /* all values read */
           i++;
           kmax = k;
           k = 0;
           //printf("i = %d\n",i);		   
        } 
     }
     pch = strtok(NULL," ");
   } // while pch 
  } // if #
 } // while line
 i = i-1; /* -1 for final i++ */
 imax = i;

 /* close file */
 fclose(fp);
	
 if((imax < 1) || (k != 0) || kmax != NVAL){
   sprintf(mssg,"freadcoords(): Error reading coordinates '%s'",fpstr);
   printf("i k l = %d %d %d\n",i,k,l);	
   printf("imax kmax l = %d %d %d\n",imax,kmax,l);	
   printf("\n+++ Coord input file: Try removing spaces after '\\',"
          " end of lines, etc.\n");	
   ferrx(mssg);
 }

 /* extract variables from y */
 for(i=1;i<=nreq;i++){
     m[i]    = y[i][1];
     x[i][1] = y[i][2];
     x[i][2] = y[i][3];
     x[i][3] = y[i][4];
     v[i][1] = y[i][5];
     v[i][2] = y[i][6];
     v[i][3] = y[i][7];
 }

 printf("@ Done reading coordinates of %d bodies (excl. central mass).\n",imax);	
 printf("@ Requested: %d\n\n",nreq);	
 if(nreq > imax){
   printf("Bodies requested > Bodies read.");	
   sprintf(mssg,"freadcoords(): Error reading coordinates '%s'",fpstr);
   ferrx(mssg);
 }
	
 free_dmatrix(y,1,NMAX,1,NVAL);

}
/*============================================================*/
/*===================== freadcoords() END ====================*/
/*============================================================*/

/*============================================================*/
/*===================== fopenwrt() ===========================*/
/*============================================================*/
/* 
  open files for output, return file pointer 
*/
void fopenwrt(FILE **fperg, char *fnerg, FILE **fplog, char *fnlog)
{
 char mssg[BUFSIZ];	
	
 *fperg = fopen(fnerg,"a");
 if(*fperg == NULL){ 
    sprintf(mssg,"fopenwrt(): Can't open file for writing energy");
	ferrx(mssg);
 }

 *fplog= fopen(fnlog,"a");
 if(*fplog == NULL){ 
    sprintf(mssg,"fopenwrt(): Can't open file for writing integration log");
	ferrx(mssg);
 }

}
/*============================================================*/
/*===================== fopenwrt() END =======================*/
/*============================================================*/

/*============================================================*/
/*======== fget_eccvec() & fmean_anomaly() & acos_r() ========*/
/*============================================================*/
/*
  calculate ecc vector ev, norm ee
*/
void fget_eccvec(double *ev, double *ee, double *x, double *v, 
                 double *hv, double ri, double eta0i)
{
 double u[CDIM];
 vcross(u,v,hv);
 vsclr(ev,eta0i,u,3);
 ev[1] -= x[1]*ri;
 ev[2] -= x[2]*ri;
 ev[3] -= x[3]*ri;
 *ee = NORM(ev);
}
/*============================================================*/
/*============================================================*/
/*
  calculate mean anomaly from true anomaly
*/
double fmean_anomaly(double e, double nu)
{
 double mn=0.;
 if(e < 1.0){                       /* elliptical */
    double zi = sqrt((1.-e)/(1.+e));
    /* calc ecc anomaly first: ea */
    double ea = 2.*atan(tan(0.5*nu)*zi);
    /* mn: mean anomaly */
    mn = ea - e*sin(ea);
 } else if(e > 1.0){                /* hyperbolic */
    double zi = sqrt((e-1.)/(e+1.));
    /* calc hyp anomaly first: ha */
    double ha = 2.*atanh(tan(0.5*nu)*zi); /* atan hyperbolic ! */
    /* mn: mean anomaly */
    mn = -ha + e*sinh(ha);
    mn = fwraptopi_mod(mn);
 } else {                           /* parabolic */
    /* rare case. Barker's equation may yield
       jumps across e = 1. => set mn to zero ? */
    /*
    double hp = tan(0.5*nu);
    mn = hp + hp*hp*hp/3.;
    mn = fwraptopi_mod(mn);
    */
    mn = 0.;
 }
 return(mn);
}
/*============================================================*/
/*============================================================*/
/*
  acos_r() restrict output: nan -> PI, 0
*/
double acos_r(double x)
{
 double y=0.;
 if(fabs(x) < 1.){
     y = acos(x);
 } else {
     if(x <= -1.) y = PI;
     if(x >=  1.) y = 0.; 
 }
 return(y);
}
/*============================================================*/
/*======== fget_eccvec() & fmean_anomaly() & acos_r() END ====*/
/*============================================================*/

/*============================================================*/
/*===================== fxv2elm() ============================*/
/*============================================================*/
/*
  Input = body coords. Output = orbital elements

  !!! FOR ACCURACY AND STORAGE DO NOT USE ELEMENTS !!!
  !!! USE STATE VECTORS X V                        !!!

  For small or zero values of inclination and/or eccentricity, 
  the cases below mostly avoid NaN output (elements may not be 
  accurate in those cases!) 
  
  If output shows errors, try to raise ECC_SMALL, INC_SMALL
  (see below)

  ecc/inc cases: all for 0 <= e < 1 (circ / elliptic)
  TABLE NOTE: ">0" means >X_SMALL. "=0" means <=X_SMALL
  ============================================================
  ecc      inc    om(ArgP)   Om(LAN)   vpi(LonP)   M(MeanAn)
  ------------------------------------------------------------
  e>0      i>0    OK         OK        OK Om+om    OK
  e>0      i=0    OK         undef     = om        OK
  e=0      i>0    undef      OK        = Om        angle n-r
  e=0      i=0    undef      undef     undef       angle xaxis-r
  ============================================================
*/
#define ECC_SMALL 1.*DBL_EPS /* e_s */
#define INC_SMALL 1.*DBL_EPS /* i_s */
//#define ECC_SMALL 1.e-14 /* e_s */
//#define INC_SMALL 1.e-14 /* i_s */

#define E_NORM_I_NORM 1 /* e_s  < e < 1 && i >  i_s */
#define E_NORM_I_SMLL 2 /* e_s  < e < 1 && i <= i_s */
#define E_SMLL_I_NORM 3 /* e   <= e_s   && i >  i_s */
#define E_SMLL_I_SMLL 4 /* e   <= e_s   && i <= i_s */
/*============================================================*/
void fxv2elm(struct elements *elm, double *x, double *v, 
             double eta0)
{
 const double eta0i = 1./eta0;
 double hv[CDIM],h,r,ri,p,xv,ev[CDIM],ee,er,nu;
 double n0[CDIM] = {NAN, 0., 0., 1.};
 double nv[CDIM],nn,ne,nr;
 char mssg[BUFSIZ];
 int ei_case = 0;
 double *a   = &elm->a;   /* semimajor axis */
 double *e   = &elm->e;   /* eccentricity   */
 double *inc = &elm->i;   /* inclination    */
 double *om  = &elm->om;  /* ArgPerihelion  */
 double *oom = &elm->oom; /* LongAscNode    */
 double *vpi = &elm->vpi; /* LongPerihelion */
 double *mn  = &elm->mn;  /* mean anomaly   */

 vcross(hv,x,v);
 h  = NORM(hv);
 r  = NORM(x);
 ri = 1./r;
 p  = h*h*eta0i;
 xv = vvdot(x,v,3);
 double z1 = p*ri - 1.;
 double z2 = h*xv*eta0i*ri;
 
 /* e: eccentricity */
 *e = sqrt(z1*z1 + z2*z2);

 /* a, inc: semimajor axis, inclination */
 if(fabs(*e-1.) > DBL_EPS){
    *a = p/(1.-(*e)*(*e)); /* elliptical & hyperbolic */
 } else {
    *a = 1./DBL_EPS;       /* parabolic */
 }
 *inc = acos(hv[3]/h);

 /* ecc/inc: set ei-case */
 if(fabs(*e) > ECC_SMALL){
    if(*inc > INC_SMALL && (PI-*inc) > INC_SMALL) 
         ei_case = E_NORM_I_NORM; // 1
    else ei_case = E_NORM_I_SMLL; // 2
 } else {
    if(*inc > INC_SMALL && (PI-*inc) > INC_SMALL) 
         ei_case = E_SMLL_I_NORM; // 3
    else ei_case = E_SMLL_I_SMLL; // 4 
 }

 switch(ei_case)
  {
   /*===================================================*/
   case E_NORM_I_NORM: // 1
   
        /* calculate ecc vector ev, norm ee */
        fget_eccvec(ev,&ee,x,v,hv,ri,eta0i); // *e-ee ~= eps
        /* calculate n-vec (points to node) and nv dot ev */
        vcross(nv,n0,hv);
        nn = NORM(nv);
        ne = vvdot(nv,ev,3);
        /* om: ArgPerihelion [0 2PI] */
        *om = acos_r(ne/(nn*ee));
        if(ev[3] < 0.)
          *om = 2.*PI - *om;
        /* oom: LongAscNode [-PI PI] */
        *oom = atan2(hv[1],-hv[2]);
        /* vpi: LongPerihelion */
        *vpi = *oom + *om;
        /* wrap om, vpi to [-PI PI] */
        *om  = fwraptopi(*om);
        *vpi = fwraptopi(*vpi);
        /* calc true anomaly first: nu */
        er = vvdot(ev,x,3);
        nu = acos_r(er/(ee*r));
        if(xv < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(ee,nu);

        break;
   /*===================================================*/
   case E_NORM_I_SMLL: // 2

        /* calculate ecc vector ev, norm ee */
        fget_eccvec(ev,&ee,x,v,hv,ri,eta0i); // *e-ee ~= eps
        /* oom: LongAscNode set to zero */
        *oom = 0.;
        /* om: ArgPerihelion (angle xaxis-ecc vector) [-PI PI] */
        *om = atan2(ev[2],ev[1]);
        /* vpi: LongPerihelion */
        *vpi = *om;
        /* calc true anomaly first: nu */
        er = vvdot(ev,x,3);
        nu = acos_r(er/(ee*r));
        if(xv < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(ee,nu);

        break;      
   /*===================================================*/
   case E_SMLL_I_NORM: // 3

        /* calculate n-vec (points to node) and nv dot ev */
        vcross(nv,n0,hv);
        nn = NORM(nv);
        /* oom: LongAscNode [-PI PI] */
        *oom = atan2(hv[1],-hv[2]);
        /* om: ArgPerihelion set to zero */
        *om = 0.;
        /* vpi: LongPerihelion */
        *vpi = *oom;
        /* calc true anomaly first: nu */        
        /* true anomaly here: angle n-r */
        nr = vvdot(nv,x,3);
        nu = acos_r(nr/(nn*r));
        if(x[3] < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(*e,nu); // *e NOT ee

        break;
   /*===================================================*/
   case E_SMLL_I_SMLL: // 4

        /* oom: LongAscNode set to zero    */
        *oom = 0.;
        /* om: ArgPerihelion set to zero   */
        *om  = 0.;
        /* vpi: LongPerihelion set to zero */
        *vpi = 0.;
        /* calc true anomaly first: nu */
        /* true anomaly here: angle xaxis-r */
        nu = atan2(x[2],x[1]);
        /* mn: mean anomaly */
        *mn = fmean_anomaly(*e,nu); // *e NOT ee

        break;
   /*===================================================*/
   default:
        sprintf(mssg,"fxv2elm(): ei_case failed. e = %e inc = %e",*e,*inc);
        ferrx(mssg);
 }

#ifdef ANG_DEG
 *inc = *inc*R2D;
 *om  =  *om*R2D;
 *oom = *oom*R2D;
 *vpi = *vpi*R2D;
 *mn  =  *mn*R2D;
#endif

}
/*============================================================*/
/*===================== fxv2elm() END ========================*/
/*============================================================*/

/*============================================================*/
/*===================== fwrtOrbxyz() =========================*/
/*============================================================*/
/*
 Default output is bodycentrics.
 If input is body, do nothing (copy):          flag = 0
 If input is bary, convert to body:            flag = 1
 If input is Jac , convert to bary, then body: flag = 2 
 (main loop uses Jacobi)
*/
void fwrtOrbxyz(FILE **fporbj, double t, double **x, double **v, 
     double *m, double *msumj, const int jmax, int flag)
{
 extern double **x_,**v_; /* memory dummies */
 int j;
 double **xw=x_,**vw=v_;
 char mssg[BUFSIZ];
 char ff[BUFSIZ]="%.15g %24.16e %24.16e %24.16e %24.16e %24.16e %24.16e\n"; 

 /* always init coord for calc/write. do not overwrite **x **v */
 
 if(flag == 0)  /* input is body, make copy */
    fcopyxv(xw,vw,x,v,jmax);
 if(flag == 1)  /* input is bary, convert to body */
    fbary2body(xw,vw,x,v,m,jmax);
 // TODO TEST !!!
 if(flag == 2){ /* input is Jac , convert to bary, then body */
    fjac2inert(xw,vw,x,v,m,msumj,jmax);
    fbary2body(xw,vw,xw,vw,m,jmax);
 }
 if(flag < 0 || flag > 2){
    sprintf(mssg,"fwrtOrbxyz(): set flag = 0,1,2 (body,bary,jac input)");
	ferrx(mssg);
 }

 for(j=0;j<=jmax;j++){ // j=0 !!!
  fprintf(fporbj[j],ff,t,xw[j][1],xw[j][2],xw[j][3],vw[j][1],vw[j][2],vw[j][3]);
  fflush(fporbj[j]);
 }

}
/*============================================================*/
/*===================== fwrtOrbxyz() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fwrtOrbelm() =========================*/
/*============================================================*/
/*
 Default output is bodycentrics.
 If input is body, do nothing (copy):          flag = 0
 If input is bary, convert to body:            flag = 1
 If input is Jac , convert to bary, then body: flag = 2 
 (main loop uses Jacobi)
*/
void fwrtOrbelm(FILE **fporbj, double t, double **x, double **v, 
     double *m, double *msumj, double *eta, const int jmax, 
     int flag)
{
 extern double **x_,**v_; /* memory dummies */
 int j;
 double **xw=x_,**vw=v_;
 UNUSED(eta);
 struct elements elm; 
 char mssg[BUFSIZ];
 char ff[BUFSIZ]="%.15g %24.16e %24.16e %24.16e %24.16e %24.16e %24.16e %24.16e\n";
 
 /* always init coord for calc/write. do not overwrite **x **v */

 if(flag == 0)  /* input is body, make copy */
    fcopyxv(xw,vw,x,v,jmax);
 if(flag == 1)  /* input is bary, convert to body */
    fbary2body(xw,vw,x,v,m,jmax);
 // TODO TEST!!!
 if(flag == 2){ /* input is Jac , convert to bary, then body */
    fjac2inert(xw,vw,x,v,m,msumj,jmax);
    fbary2body(xw,vw,xw,vw,m,jmax);
 }
 if(flag < 0 || flag > 2){
    sprintf(mssg,"fwrtOrbelm(): set flag = 0,1,2 (body,bary,jac input)");
	ferrx(mssg);
 }

 for(j=1;j<=jmax;j++){ // j = 1 !!!
     const double eta0 = (m[0]+m[j]*ELM_MJ)*(KGAUSS*KGAUSS);
     fxv2elm(&elm,xw[j],vw[j],eta0);
     fprintf(fporbj[j],ff,t, \
             elm.a,elm.e,elm.i,elm.om,elm.oom,elm.vpi,elm.mn);
     fflush(fporbj[j]);
 }

}
/*============================================================*/
/*===================== fwrtOrbelm() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fwrtOrb() ============================*/
/*============================================================*/
/*
  switch output between orbital elements and state xv
*/
void fwrtOrb(FILE **fporbj, double t, double **x, double **v, 
     double *m, double *msumj, double *eta, const int jmax, 
     int flag)
{

#ifdef ORB_XV
 UNUSED(eta);
 fwrtOrbxyz(fporbj,t,x,v,m,msumj,jmax,flag);
#else
 fwrtOrbelm(fporbj,t,x,v,m,msumj,eta,jmax,flag);
#endif

}
/*============================================================*/
/*===================== fwrtOrb() ============================*/
/*============================================================*/

/*============================================================*/
/*===================== fwrtErgAng() =========================*/
/*============================================================*/
void fwrtErgAng(FILE *fperg, double t, double erg, double erg0,
                double *lv, double *lv0, double l0)
{
 char ff[BUFSIZ]="%.15g %19.12e %19.12e %19.12e %19.12e\n";

 fprintf(fperg,ff,t,(erg-erg0)/erg0,(lv[1]-lv0[1])/l0, \
                  (lv[2]-lv0[2])/l0,(lv[3]-lv0[3])/l0);
 fflush(fperg);

}
/*============================================================*/
/*===================== fwrtErgAng() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fcheck() =============================*/
/*============================================================*/
/*
  check selected parameters and issue warnings and errors
*/
 void fcheck(FILE *fplog, double **x0, double **v0,
             const double dt, double t0, double tend,
             double tfin, double *m, const double k2,
             const int jmax, const int sstep)
 {
  int j,jm=-1;
  char mssg[BUFSIZ];
  char *wrn="*** WARNING:";
  char *err="*** ERROR:";
  struct elements elm;

  if(tend > t0 && dt < 0.){
     sprintf(mssg, \
     "fcheck(): tend > t0 but timestep dt < 0. Check input");
     fprintf(fplog,"\n%s\n%s\n*** Exiting\n",err,mssg);
     ferrx(mssg);
  }
  if(tend < t0 && dt > 0.){
     sprintf(mssg, \
     "fcheck(): tend < t0 but timestep dt > 0. Check input");
     fprintf(fplog,"\n%s\n%s\n*** Exiting\n",err,mssg);
     ferrx(mssg);
  }

  if(fabs(sstep*dt) > fabs(tfin-t0)){
     sprintf(mssg, \
      "fwrtLog(): Save interval > Run interval. Lacking output?\n"
      "Change tend or reduce SaveStep");
     fprintf(fplog,"\n%s\n%s\n*** Continuing\n",wrn,mssg);
     fwarn(mssg);
  }

  /* check timestep |dt|. calc tau_f/16, see Hernandez et al. 2022 */
  double gm = m[0]*k2;
  double tauf_min=1.e308;
  double stpi = 1./16.;
  for(j=1;j<=jmax;j++){
     const double eta0 = (m[0]+m[j]*ELM_MJ)*k2;
     fxv2elm(&elm,x0[j],v0[j],eta0);
     double a3 = elm.a*elm.a*elm.a;
     double u = 1.-elm.e;
     double tauf = 2.*PI*sqrt(u*u*u*a3/((1.+elm.e)*gm));
     if(tauf < tauf_min && elm.e < 1.){ /* 05/17/23: && elm.e<1 */
        jm = j;
        tauf_min = tauf;
     }
  }
  if(fabs(dt) > tauf_min*stpi){
     sprintf(mssg, \
      "fwrtLog(): Timestep |dt| = %.3f may be too large to resolve\n"
      "pericenter for body No. %d. Recommended |dt| < %.3f at t=t0.",\
       fabs(dt),jm,tauf_min*stpi);
     fprintf(fplog,"\n%s\n%s\n*** Continuing\n",wrn,mssg);
     fwarn(mssg);
  }

 }
/*============================================================*/
/*===================== fcheck() END =========================*/
/*============================================================*/

/*============================================================*/
/*===================== fwrtLog() ============================*/
/*============================================================*/
void fwrtLog(FILE *fplog, double **x0, double **v0, double dt,
             double t0, double tend, double *m, const int sstep,
             double erg0, double *lv0, const double k2, 
             const double c2, const int jmax, int flag)
{
 int j;
 UNUSED(k2);
 time_t t = time(NULL);
 struct tm *tm = localtime(&t);

 /* write parameters to integration log file */
 if(flag == 0){
  fprintf(fplog,"%s\n",asctime(tm));

  fprintf(fplog,"*** orbitN comes with ABSOLUTELY NO WARRANTY ***\n");		 
  fprintf(fplog,"*** Use at your own risk. DO NOT DISTRIBUTE  ***\n\n");

  fprintf(fplog,"This is %s\n",VER);
  fprintf(fplog,"Richard E. Zeebe. orbitN.code@gmail.com\n\n");
  fflush(fplog);

#ifdef CPUINFO
  /* host & cpu info. get predefs: gcc -x c /dev/null -dM -E */
  int chk;
  char *fnlog="orbitN.log",cmd[BUFSIZ];
  /* host info */
  fprintf(fplog,"This job is running on host ");
  sprintf(cmd,"hostname >> %s",fnlog);
  fflush(fplog);
  chk = system(cmd); 
  if(chk == -1)
     fwarn("fwrtLog(): chk = system(cmd) = -1. Disable CPUINFO.");
  /* cpu info */
#ifdef __linux__
  fprintf(fplog,"OS linux. CPU info\n");
  sprintf(cmd,"cat /proc/cpuinfo | grep name | head -n 1 >> %s",fnlog);
#endif
#ifdef __APPLE__
  fprintf(fplog,"OS mac. CPU info\n");
  sprintf(cmd,"sysctl -a | grep brand_string >> %s",fnlog);
#endif
  fflush(fplog);
  chk = system(cmd);
  if(chk == -1)
     fwarn("fwrtLog(): chk = system(cmd) = -1. Disable CPUINFO.");
  fprintf(fplog,"\n");
#endif

  /* Run parameters */
  fprintf(fplog,"Run parameters\n");
  set_intg_seq(fplog,1);

  /* timing (steps in doubles) */
  double tt = tend - t0;
  double nstep = floor(fabs(tt/dt));
  double tfin = t0 + nstep*dt; /* adjusted tend */
  double nsavefin = floor(nstep/sstep)*sstep;
  double tsavefin = t0 + nsavefin*dt;

  fprintf(fplog,"\n");
  fprintf(fplog,"Time unit        = %s     \n","day");
  fprintf(fplog,"Timestep dt      = %20.10f\n",dt);
  fprintf(fplog,"Time start       = %20.4f \n",t0);
  fprintf(fplog,"Time end         = %20.4f (input)     \n",tend);
  fprintf(fplog,"Time end         = %20.4f (adjusted)\n\n",tfin);
  fprintf(fplog,"Save interval    = %20d steps\n",sstep);
  fprintf(fplog,"Time  final save = %20.4f\n",tsavefin);
  fprintf(fplog,"Steps final save = %20.4f\n",nsavefin);

  /* check */
  fcheck(fplog,x0,v0,dt,t0,tend,tfin,m,k2,jmax,sstep);

  /* units & constants */
  fprintf(fplog,"\n");
  fprintf(fplog,"Length unit   = %s      \n","au");
  fprintf(fplog,"Constants\n");
  fprintf(fplog,"au  (m)       = %22.16e \n",AU);
  fprintf(fplog,"c   (m/s)     = %22.16e \n",C_MS);
  fprintf(fplog,"k   (rad/d)   = %18.16f \n",KGAUSS);
  fprintf(fplog,"c^2 (au/d)^2  = %22.16e \n",c2);

  /* central mass */
  fprintf(fplog,"\n");
  fprintf(fplog,"Central mass\n");
  fprintf(fplog,"m[0]          = %18.16f \n",m[0]);

  /* orbital output & angle units */
  fprintf(fplog,"\n");
#ifdef ORB_XV
  fprintf(fplog,"Orbital output: State vectors X V\n");
  fprintf(fplog,"*** Save the coordinate input file (masses) for post-run "
                "conversion to Keplerian elements ***\n");
#else
  fprintf(fplog,"Orbital output: Keplerian elements ");
  fprintf(fplog,"[a e i om oom vpi mn]\n");
  fprintf(fplog,"[SemiMajor Ecc Inc ArgPerh ");
  fprintf(fplog,"LongAscNode LongPerh MeanAnom]\n");
  #ifdef ANG_DEG
    fprintf(fplog,"Angle units: deg\n");
  #else
    fprintf(fplog,"Angle units: rad\n");
  #endif
  /* // 05/17/23
  char mssg[BUFSIZ]; // 04/23/23
  sprintf(mssg, \
    "fwrtLog(): Output Keplerian elements. Case e>=1 to be implemented.");
  fprintf(fplog,"%s\n",mssg);
  fwarn(mssg);
  */
#endif

#ifdef J2
  /* Solar quadrupole parameters (oblateness) */
  char mssg[BUFSIZ];
  sprintf(mssg, \
   "J2 = ON needs initial coordinates in proper frame");
  fprintf(fplog,"\n%s\n",mssg);
  printf("@ %s.\n\n",mssg);
  fprintf(fplog,"\nSolar quadrupole parameters (oblateness)\n");
  fprintf(fplog,"J2 = %22.15e\n",OBLTJ2);
  fprintf(fplog,"R  = %18.15f\n",OBLTR);
#endif

#ifdef LUNAR
  /* Lunar factor (Quinn91, Varadi03) */
  fprintf(fplog,"\nLunar factor\n");
  fprintf(fplog,"f_L = %.15f\n",F_LUNAR);
#endif

#ifdef CORR
  /* Corrector (Wisdom06) */
  fprintf(fplog,"\nSymplectic Corrector\n");
  fprintf(fplog,"Stage = %d (Order = %d)\n",STAGE,STAGE+1);
#endif

  /* energy & angular momentum */
  fprintf(fplog,"\nStarting energy & angular momentum\n");
  fprintf(fplog,"E0 = %22.15e\n",erg0);
  fprintf(fplog,"L0 = %22.15e %22.15e %22.15e\n",lv0[1],lv0[2],lv0[3]);    

  /* bodies & coords */
  fprintf(fplog,"\nNo. of bodies incl. central mass = %d\n",jmax+1);  
  fprintf(fplog,"Input/Output coordinates = Bodycentric\n\n");
  fprintf(fplog,"Masses and initial coordinates [m x0 y0 z0 u0 v0 w0]\n");
  char ff[BUFSIZ]="%22.16e %23.16e %23.16e %23.16e %23.16e %23.16e %23.16e\n";
  for(j=0;j<=jmax;j++)
  fprintf(fplog,ff,m[j],x0[j][1],x0[j][2],x0[j][3], \
                        v0[j][1],v0[j][2],v0[j][3]);

  fprintf(fplog,"\nStarting integration\n\n");                   
 }

 /* write final items to integration log file */
 if(flag == 1){
  fprintf(fplog,"\n%s",asctime(tm));
 }

}
/*============================================================*/
/*===================== fwrtLog() END ========================*/
/*============================================================*/

/*============================================================*/
/*===================== fwall_time() =========================*/
/*============================================================*/
void fwall_time(clock_t tick0, clock_t tick, double t, double t0,
                double tend, unsigned long long ii, int saveflag,
                FILE *fplog)
{
 double twall = (double)(tick-tick0)/CLOCKS_PER_SEC;
 double tremn = ((tend-t0)/(t-t0)-1.)*twall;
 char *cw="sec",*cr="sec",*cmin="min",*ch="h";

 if(twall > 60. && twall < 3600.){
    twall *= 1.666666666666667e-02;
    cw = cmin;
 }
 if(twall > 3600.){
    twall *= 2.777777777777778e-04;
    cw = ch; 
 }

 if(tremn > 60. && tremn < 3600.){
    tremn *= 1.666666666666667e-02;
    cr = cmin;
 }
 if(tremn >= 3600.){
    tremn *= 2.777777777777778e-04;
    cr = ch;
 }

 if(saveflag){
    fprintf(fplog,"Writing Output Files. ");
 } else {
    fprintf(fplog,"                      ");
 }
 fprintf(fplog,"t = %.4f. Steps = %llu.\n",t,ii);
 fprintf(fplog,"Wallclock Time = %9.4f %s.",twall,cw);
 fprintf(fplog," Est. Time Remaining = %9.4f %s\n\n",tremn,cr);

 fflush(fplog);

}
/*============================================================*/
/*===================== fwall_time() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fsave_fin() ==========================*/
/*============================================================*/
/*
  save final coords & bits (int_x) for new run/restart
*/
void fsave_fin(double **xx, double **vv, double **cx, double **cv,
               const int jmax)
{
 int j;
 char mssg[BUFSIZ];
 char ff[BUFSIZ]="%25.17e %25.17e %25.17e %25.17e %25.17e %25.17e\n";
 FILE *fp = fopen(SAVEFILE,"w");
 if(fp == NULL){
    sprintf(mssg,"fsave_fin(): Can't open file (w) for save: '%s'",SAVEFILE);
    ferrx(mssg);
 }

 for(j=0;j<=jmax;j++)
  fprintf(fp,ff,xx[j][1],xx[j][2],xx[j][3],vv[j][1],vv[j][2],vv[j][3]);
 for(j=0;j<=jmax;j++)
  fprintf(fp,ff,cx[j][1],cx[j][2],cx[j][3],cv[j][1],cv[j][2],cv[j][3]);
 fclose(fp);

}
/*============================================================*/
/*===================== fsave_fin() END ======================*/
/*============================================================*/

/*============================================================*/
/*===================== fload_sve() ==========================*/
/*============================================================*/
/*
  load saved coords & bits (int_x) for new run/restart
*/
void fload_sve(double **xx, double **vv, double **cx, double **cv,
               const int jmax)
{
 int j,chk;
 char mssg[BUFSIZ];
 char ff[BUFSIZ]="%lf %lf %lf %lf %lf %lf\n";
 FILE *fp = fopen(SAVEFILE,"r");
 if(fp == NULL){
    sprintf(mssg,"fload_sve(): Can't open save file (r): '%s'",SAVEFILE);
    ferrx(mssg);
 }

 for(j=0;j<=jmax;j++){
  chk = fscanf(fp,ff,&xx[j][1],&xx[j][2],&xx[j][3], \
                     &vv[j][1],&vv[j][2],&vv[j][3]);
  if(chk != 6){
     sprintf(mssg,"fload_sve(): #Values read != 6");
     ferrx(mssg);
  }
 }
 for(j=0;j<=jmax;j++){
  chk = fscanf(fp,ff,&cx[j][1],&cx[j][2],&cx[j][3], \
                     &cv[j][1],&cv[j][2],&cv[j][3]);
  if(chk != 6){
     sprintf(mssg,"fload_sve(): #Values read != 6");
     ferrx(mssg);
  }
 }
 fclose(fp);

}
/*============================================================*/
/*===================== fload_sve() END ======================*/
/*============================================================*/

/*============================================================*/
/*===================== fload_conv() =========================*/
/*============================================================*/
/*
  if fload_sve(): convert coords. only needed for writing
  proper start values at t0.
*/
void fload_conv(double *erg, double *lv,
                double **x, double **v, double **dx, double **dv,
                double **xb, double dt, struct masses mm,
                const double k2, const double c2i, const double c2,
                const int jmax, int inv, const int stage)
{
 extern double **x_,**v_; /* dummies */
 int coordflag = 1; /* calc E, L: coords = jac */

 fload_sve(x,v,x_,v_,jmax);

 printf("\n@ fload_conv(): converting coordinates at t0.\n");
 /* get integration sequence based on macros in orbitN.h  */
 int intg_seq = set_intg_seq(NULL,0);
 printf("@ fload_conv(): intg_seq = %d\n",intg_seq);

 /* conversion for slow -> jac */
 if(intg_seq == 1){
    finert2jac(x,v,x,v,mm.m,mm.msumj,jmax);
 }

 /* conversion for fast and fast_pn -> jac */
 if(intg_seq > 1){
#ifdef CORR
    fcorr(x,v,dx,dv,xb,dt,mm.m,mm.msumj,mm.eta,k2,c2i,jmax,inv,stage);
#else
    UNUSED(dx),UNUSED(dv),UNUSED(xb),UNUSED(dt),UNUSED(c2i),
    UNUSED(inv),UNUSED(stage);
#endif
#ifdef PN
    fpseudo2jac_v(v,x,v,mm,k2,c2,jmax);
#else
    UNUSED(mm),UNUSED(k2),UNUSED(c2);
#endif
 }

 /* Energy & Angular Momentum t0 */
 *erg = fenergy(x,v,mm,k2,c2,jmax,coordflag);
 fangm(lv,x,v,mm,k2,c2,jmax,coordflag);

}
/*============================================================*/
/*===================== fload_conv() END =====================*/
/*============================================================*/
