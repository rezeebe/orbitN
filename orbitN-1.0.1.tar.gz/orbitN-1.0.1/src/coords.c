/***************************************************************

   orbitN VERSION: 1.0.1 (05/2025)
   file: coords.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2025 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   updates:

   05/54/25 simplified fbary2body()
   03/04/23

   TODO:

***************************************************************/
#include <stdio.h>
#include "orbitN.h"

/*============================================================*/
/*===================== fjacmass() ===========================*/
/*============================================================*/
void fjacmass(double *mj, double *msumj, double *eta, double *m, 
              struct masses *mm, const double k2, const int jmax)
{
 int j;
 double sumtoj=m[0];

 mj[0] = m[0];
 msumj[0] = m[0];
 eta[0] = NAN;

 for(j=1;j<=jmax;j++){
     sumtoj = sumtoj + m[j]; 
   msumj[j] = sumtoj;
      mj[j] = m[j]*msumj[j-1]/msumj[j];
     eta[j] = k2*sumtoj;
 }

 /* collect all in mm */
 for(j=0;j<=jmax;j++){
     mm->m[j] = m[j];
     mm->mj[j] = mj[j];
     mm->msumj[j] = msumj[j];
     mm->eta[j] = eta[j];
  }
 
}
/*============================================================*/
/*===================== fjacmass() END =======================*/
/*============================================================*/

/*============================================================*/
/*===================== finert2jac() =========================*/
/*============================================================*/
/* input  = inertia coords/veloc of masses m for 0 to J.
   output = Jacobi  coords/veloc
   in/output index j0 = 0 is CENTRAL/CENTER (!) mass
   see ReinTamayo15                                           */

void finert2jac(double **xj, double **vj, double **xx, 
    double **vv, double *m, double *msumj, const int jmax)
{
 int j;
 double mx[3+1],mv[3+1],tmp;
 const double m0=m[0],msumjmaxi=1./msumj[jmax];

 mx[1] = m0*xx[0][1];
 mx[2] = m0*xx[0][2];
 mx[3] = m0*xx[0][3];
 mv[1] = m0*vv[0][1];
 mv[2] = m0*vv[0][2];
 mv[3] = m0*vv[0][3];

 for(j=1;j<=jmax;j++){
   tmp = 1./msumj[j-1];
   xj[j][1] = xx[j][1] - mx[1]*tmp; 
   xj[j][2] = xx[j][2] - mx[2]*tmp;
   xj[j][3] = xx[j][3] - mx[3]*tmp;
   vj[j][1] = vv[j][1] - mv[1]*tmp; 
   vj[j][2] = vv[j][2] - mv[2]*tmp;
   vj[j][3] = vv[j][3] - mv[3]*tmp;
   tmp = msumj[j]*tmp;   
   //tmp = (1. + m[j]/msumj[j-1]);   
   mx[1] = mx[1]*tmp + m[j]*xj[j][1];
   mx[2] = mx[2]*tmp + m[j]*xj[j][2];
   mx[3] = mx[3]*tmp + m[j]*xj[j][3];	 
   mv[1] = mv[1]*tmp + m[j]*vj[j][1];
   mv[2] = mv[2]*tmp + m[j]*vj[j][2];
   mv[3] = mv[3]*tmp + m[j]*vj[j][3];	 
 }
 /* center of mass */
 //tmp = 1./msumjmax;
 xj[0][1] = mx[1]*msumjmaxi;
 xj[0][2] = mx[2]*msumjmaxi;
 xj[0][3] = mx[3]*msumjmaxi;
 vj[0][1] = mv[1]*msumjmaxi;
 vj[0][2] = mv[2]*msumjmaxi;
 vj[0][3] = mv[3]*msumjmaxi;

}
/*============================================================*/
/*===================== finert2jac() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== finert2jac_a() =======================*/
/*============================================================*/
/* input  = inertia accelerations of masses m for 0 to J.
   output = Jacobi  accelerations
   in/output index j0 = 0 is CENTRAL/CENTER (!) mass          */

void finert2jac_a(double aa[][CDIM], const double *m, 
                  const double *msumj, const int jmax)
{
 int j;
 const double m0=m[0],msumjmaxi=1./msumj[jmax];
 double ma[3+1],tmp;

 ma[1] = m0*aa[0][1];
 ma[2] = m0*aa[0][2];
 ma[3] = m0*aa[0][3];

 for(j=1;j<=jmax;j++){
     tmp = 1./msumj[j-1];
     aa[j][1] = aa[j][1] - ma[1]*tmp;
     aa[j][2] = aa[j][2] - ma[2]*tmp;
     aa[j][3] = aa[j][3] - ma[3]*tmp;
     tmp = msumj[j]*tmp;     
     ma[1] = ma[1]*tmp + m[j]*aa[j][1];
     ma[2] = ma[2]*tmp + m[j]*aa[j][2];
     ma[3] = ma[3]*tmp + m[j]*aa[j][3];
 }
 /* center of mass */
 aa[0][1] = ma[1]*msumjmaxi;
 aa[0][2] = ma[2]*msumjmaxi;
 aa[0][3] = ma[3]*msumjmaxi;

}
/*============================================================*/
/*===================== finert2jac_a() END ===================*/
/*============================================================*/

/*============================================================*/
/*===================== fjac2inert() =========================*/
/*============================================================*/
/* input  = Jacobi  coords/veloc of masses m for 0 to J.
   output = inertia coords/veloc.
   in/output index j0 = 0 is CENTER/CENTRAL (!) mass
   see ReinTamayo15                                           */

void fjac2inert(double **xi, double **vi, double **x, 
    double **v, double *m, double *msumj, const int jmax)
{
 int j;
 double mx[3+1]={NAN, 0., 0., 0.},mv[3+1]={NAN, 0., 0., 0.},tmp;
 const double msumjmax=msumj[jmax],m0i=1./m[0];

 mx[1] = msumjmax*x[0][1];
 mx[2] = msumjmax*x[0][2];
 mx[3] = msumjmax*x[0][3];
 mv[1] = msumjmax*v[0][1];
 mv[2] = msumjmax*v[0][2];
 mv[3] = msumjmax*v[0][3];

 for(j=jmax;j>=1;j--){
   tmp = 1./msumj[j];
   mx[1] = (mx[1] - m[j]*x[j][1])*tmp;
   mx[2] = (mx[2] - m[j]*x[j][2])*tmp;
   mx[3] = (mx[3] - m[j]*x[j][3])*tmp;
   mv[1] = (mv[1] - m[j]*v[j][1])*tmp;
   mv[2] = (mv[2] - m[j]*v[j][2])*tmp;
   mv[3] = (mv[3] - m[j]*v[j][3])*tmp;
   xi[j][1] = x[j][1] + mx[1];
   xi[j][2] = x[j][2] + mx[2];
   xi[j][3] = x[j][3] + mx[3];
   vi[j][1] = v[j][1] + mv[1];
   vi[j][2] = v[j][2] + mv[2];
   vi[j][3] = v[j][3] + mv[3];
   tmp = msumj[j-1];	 
   mx[1] *= tmp;
   mx[2] *= tmp;
   mx[3] *= tmp;
   mv[1] *= tmp;
   mv[2] *= tmp;
   mv[3] *= tmp;
 }
 /* central mass */
 xi[0][1] = mx[1]*m0i;
 xi[0][2] = mx[2]*m0i;
 xi[0][3] = mx[3]*m0i;
 vi[0][1] = mv[1]*m0i;
 vi[0][2] = mv[2]*m0i;
 vi[0][3] = mv[3]*m0i;
	
}
/*============================================================*/
/*===================== fjac2inert() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fjac2inert_x() =======================*/
/*============================================================*/
/* input  = Jacobi coords of masses m for 0 to J.
   output = inertia coords.
   in/output index j0 = 0 is CENTER/CENTRAL (!) mass          */

void fjac2inert_x(double **xi, double **x, double *m, 
                  double *msumj, const int jmax)
{
 int j;
 double mx[3+1],tmp;
 const double msumjmax=msumj[jmax],m0i=1./m[0];

 mx[1] = msumjmax*x[0][1];
 mx[2] = msumjmax*x[0][2];
 mx[3] = msumjmax*x[0][3];

 for(j=jmax;j>=1;j--){
   tmp = 1./msumj[j];
   mx[1] = (mx[1] - m[j]*x[j][1])*tmp;
   mx[2] = (mx[2] - m[j]*x[j][2])*tmp;
   mx[3] = (mx[3] - m[j]*x[j][3])*tmp;
   xi[j][1] = x[j][1] + mx[1];
   xi[j][2] = x[j][2] + mx[2];
   xi[j][3] = x[j][3] + mx[3];
   tmp = msumj[j-1];	 
   mx[1] *= tmp;
   mx[2] *= tmp;
   mx[3] *= tmp;
 }
 /* central mass */
 xi[0][1] = mx[1]*m0i;
 xi[0][2] = mx[2]*m0i;
 xi[0][3] = mx[3]*m0i;
	
}
/*============================================================*/
/*===================== fjac2inert_x() END ===================*/
/*============================================================*/

/*============================================================*/
/*===================== fcenter_of_mass() ====================*/
/*============================================================*/
void fcenter_of_mass(double *xm, double *vm, double **xx, 
                     double **vv, const double *m, const int jmax)
{
 int j;
 double msumj=m[0];
 
 xm[1] = xx[0][1];
 xm[2] = xx[0][2];
 xm[3] = xx[0][3];
 vm[1] = vv[0][1];
 vm[2] = vv[0][2];
 vm[3] = vv[0][3];
 
 for(j=1;j<=jmax;j++){
     xm[1] = xm[1]*msumj + xx[j][1]*m[j];
     xm[2] = xm[2]*msumj + xx[j][2]*m[j];
     xm[3] = xm[3]*msumj + xx[j][3]*m[j];
     vm[1] = vm[1]*msumj + vv[j][1]*m[j];
     vm[2] = vm[2]*msumj + vv[j][2]*m[j];
     vm[3] = vm[3]*msumj + vv[j][3]*m[j];
     msumj += m[j];
 	 xm[1] /= msumj;
 	 xm[2] /= msumj;
 	 xm[3] /= msumj;
 	 vm[1] /= msumj;
 	 vm[2] /= msumj;
 	 vm[3] /= msumj;
 } 

}
/*============================================================*/
/*===================== fcenter_of_mass() END ================*/
/*============================================================*/

/*============================================================*/
/*===================== fbody2bary() =========================*/
/*============================================================*/
/* input  = bodycentric coords of masses m for 0 to J.
   output = barycentric coords
   j0 = 0 is central mass m[0]                                */

void fbody2bary(double **xr, double **vr, double **xx, 
                double **vv, double *m, const int jmax)
{
 int j;
 double xm[3+1],vm[3+1];

 /* calculate center of mass */
 fcenter_of_mass(xm,vm,xx,vv,m,jmax);

 /* now body2bary */
 for(j=0;j<=jmax;j++){
      xr[j][1] = xx[j][1] - xm[1];
      xr[j][2] = xx[j][2] - xm[2];
      xr[j][3] = xx[j][3] - xm[3];
      vr[j][1] = vv[j][1] - vm[1];
      vr[j][2] = vv[j][2] - vm[2];
      vr[j][3] = vv[j][3] - vm[3];
 }

}
/*============================================================*/
/*===================== fbody2bary() END =====================*/
/*============================================================*/

#ifdef BAR_2_BOD_SMP
/*============================================================*/
/*===================== fbary2body() =========================*/
/*============================================================*/
/* input  = barycentric coords of masses m for 0 to J.
   output = bodycentric coords
   j0 = 0 is central mass m[0]                                */

void fbary2body(double **x, double **v, double **xr, 
                double **vr, double *m, const int jmax)
{
 int j;
 double x0[3+1],v0[3+1];	

 UNUSED(m);

 x0[1] = x[0][1];
 x0[2] = x[0][2];
 x0[3] = x[0][3];
 v0[1] = v[0][1];
 v0[2] = v[0][2];
 v0[3] = v[0][3];

 for(j=0;j<=jmax;j++){
   x[j][1] = xr[j][1] - x0[1];
   x[j][2] = xr[j][2] - x0[2];
   x[j][3] = xr[j][3] - x0[3];
   v[j][1] = vr[j][1] - v0[1];
   v[j][2] = vr[j][2] - v0[2];
   v[j][3] = vr[j][3] - v0[3];
 }
	
}
/*============================================================*/
/*===================== fbary2body() END =====================*/
/*============================================================*/
#else
/*============================================================*/
/*===================== fbary2body() =========================*/
/*============================================================*/
/* input  = barycentric coords of masses m for 0 to J.
   output = bodycentric coords
   j0 = 0 is central mass m[0]                                */

void fbary2body(double **x, double **v, double **xr, 
                double **vr, double *m, const int jmax)
{
 int j;	
 double mx[3+1]={NAN, 0., 0., 0.},mv[3+1]={NAN, 0., 0., 0.};
 const double m0i = 1./m[0];	

 /* j starts at 1 */
 for(j=1;j<=jmax;j++){
   mx[1] += m[j]*xr[j][1];	 
   mx[2] += m[j]*xr[j][2];	 
   mx[3] += m[j]*xr[j][3];	 
   mv[1] += m[j]*vr[j][1];	 
   mv[2] += m[j]*vr[j][2];	 
   mv[3] += m[j]*vr[j][3];	 
 }
 /* j starts at 0 */
 for(j=0;j<=jmax;j++){
   x[j][1] = xr[j][1] + mx[1]*m0i;
   x[j][2] = xr[j][2] + mx[2]*m0i;
   x[j][3] = xr[j][3] + mx[3]*m0i;
   v[j][1] = vr[j][1] + mv[1]*m0i;
   v[j][2] = vr[j][2] + mv[2]*m0i;
   v[j][3] = vr[j][3] + mv[3]*m0i;
 }
	
}
/*============================================================*/
/*===================== fbary2body() END =====================*/
/*============================================================*/
#endif

//#ifdef PN /* post-newton */
/*============================================================*/
/*===================== fjac2pseudo_v() ======================*/
/*============================================================*/
/* input  = jac coords of masses m for 1 to J.
   output = pseudo velocities
   solve by iteration, for approach see SahaTremaine94        */

void fjac2pseudo_v(double **vp, double **xj, double **vj, 
                   struct masses m, const double k2,
                   const double c2, const int jmax)
{
 int i,imax=10,j;
 const double c2i=1./c2;
 double rj,mu,v2,fac,fac1,u,v,w,tmp;
 
 /* index 0 unchanged */
 vp[0][1] = vj[0][1];
 vp[0][2] = vj[0][2];
 vp[0][3] = vj[0][3];

 for(j=1;j<=jmax;j++){
     rj = sqrt(xj[j][1]*xj[j][1]+xj[j][2]*xj[j][2]+xj[j][3]*xj[j][3]);
     mu = k2*m.msumj[j];
     //mu = k2*m.msumj[j]/m.msumj[j-1]; // ST94
     tmp = 3.*mu/rj;
     /* start value for v^2 */
     v2 = vj[j][1]*vj[j][1]+vj[j][2]*vj[j][2]+vj[j][3]*vj[j][3];
     fac = NAN;
     for(i=1;i<=imax;i++){
         fac1 = fac;
         fac = 1./(1.-(0.5*v2 + tmp)*c2i);
         if(fac == fac1){
            vp[j][1] = u;
            vp[j][2] = v;
            vp[j][3] = w;
            break;
         }
         u = vj[j][1]*fac;
         v = vj[j][2]*fac;
         w = vj[j][3]*fac;
         v2 = u*u+v*v+w*w;
     }
     if(i >= imax) \
        printf("\n+++ Warning: fjac2pseudo_v() not converged. i = %d\n",i);
 }

}
/*============================================================*/
/*===================== fjac2pseudo_v() END ==================*/
/*============================================================*/

/*============================================================*/
/*===================== fpseudo2jac_v() ======================*/
/*============================================================*/
/* input  = Jacobi positions, pseudo velocities 
   output = Jacobi velocities                                 */

void fpseudo2jac_v(double **vj, double **xj, double **vp,
                   struct masses m, const double k2,
                   const double c2, const int jmax)
{
 int j;
 const double c2i=1./c2;
 double rj,mu,vp2,fac,tmp;

 /* index 0 unchanged */
 vj[0][1] = vp[0][1];
 vj[0][2] = vp[0][2];
 vj[0][3] = vp[0][3];
 
 for(j=1;j<=jmax;j++){
     rj = sqrt(xj[j][1]*xj[j][1]+xj[j][2]*xj[j][2]+xj[j][3]*xj[j][3]);
     mu = k2*m.msumj[j];
     //mu = k2*m.msumj[j]/m.msumj[j-1]; // ST94
     tmp = 3.*mu/rj;
     /* vp^2 */
     vp2 = vp[j][1]*vp[j][1]+vp[j][2]*vp[j][2]+vp[j][3]*vp[j][3];
     fac = 1./(1.-(0.5*vp2 + tmp)*c2i);
     //double faci = 1.-(0.5*vp2 + tmp)*c2i; // faster but biased
     vj[j][1] = vp[j][1]/fac;     
     vj[j][2] = vp[j][2]/fac;     
     vj[j][3] = vp[j][3]/fac;     
 }
 
}
/*============================================================*/
/*===================== fpseudo2jac_v() END ==================*/
/*============================================================*/
//#endif
