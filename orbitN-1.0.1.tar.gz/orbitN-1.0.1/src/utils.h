/***************************************************************

   orbitN VERSION: 1.0.1 (05/2025)
   file: utils.h

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2025 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   based on nrutils.c, parts from Numerical Recipes in C.
   additions at the end

   updates:

   03/04/23

   TODO:

**************************************************************/
void nrerror(char error_text[]);
int      *ivector(long nl, long nh);
double   *dvector(long nl, long nh);
double  **dmatrix(long nrl, long nrh, long ncl, long nch);
int     **imatrix(long nrl, long nrh, long ncl, long nch);
double ***d3tensor(long nrl, long nrh, long ncl, long nch, long ndl, 
                   long ndh);

void free_ivector(int *v, long nl, long nh);
void free_dvector(double *v, long nl, long nh);
void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch);
void free_imatrix(int **m,long nrl,long nrh,long ncl,long nch);
void free_d3tensor(double ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh);

/*===================== REZ additions ================*/

/* error output */
void ferrx(char error_text[]);

/* warning output */
void fwarn(char warn_text[]);

/*** vsclr: vector X scalar  , returns vector ******/
void vsclr(double *w,double s,double *u,int n);

/*** vvdot: vector product   , returns scalar ******/
double vvdot(double *u,double *v,int n);
//void vvdot(double *s,double *u,double *v,int n);

/****** vcross: vector cross product, returns vector *******/
void vcross(double *w,double *u,double *v);

/*** vsumlh: sum vector elements, returns scalar **/
double vsumlh(double *u,int n,int nl,int nh);

/*** msumlh: sum matrix column elements, returns scalar **/
double msumlh(double **m,int krmax,int k,int n,int nl,int nh);

/*** vvsum: vector sum, returns vector *************/
void vvsum(double *w,double *u,double *v,int n);

/*** vvsub: vector subtraction, returns vector *****/
void vvsub(double *w,double *u,double *v,int n);

/*** vvelm: v-elmnt X v-elmnt, returns vector ******/
void vvelm(double *w,double *u,double *v, int n);

/*** vdelm: v-elmnt / v-elmnt, returns vector ******/
void vdelm(double *w,double *u,double *v, int n);

/*** fsetiv: init int vector elements , returns vector **/
void fsetiv(int *iv,int k,int n);

/*** fsetv: init double vector elements , returns vector **/
void fsetv(double *u,double x,int n);

/*** fvec2arr: store 2 vectors in matrix, returns matrix ******/
void fvec2arr(double **m,double *x,double *y,int n);

/*** fcopyx: make copy of x array => xc ******/
void fcopyx(double **xc, double **x, const int jmax);

/*** fcopyxv: make copy of x v arrays => xc vc ******/
void fcopyxv(double **xc, double **vc, double **x, 
              double **v, const int jmax);

/*** fcopyxv_khn: make copy of x v arrays, add dx dv => xc vc ******/
void fcopyxv_khn(double **xc, double **vc, double **x, 
             double **v, double **dx, double **dv, 
             const int jmax);
             
/*** fwraptopi: simple wrap to [-PI PI]. -3PI <= x <= 3PI ***/             
double fwraptopi(double x);

/*** fwraptopi_mod: wrap to [-PI PI] using fmod() ***/
double fwraptopi_mod(double x);

