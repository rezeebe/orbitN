/*
  high-e-mercury

  Simulate solar system with Mercury at high eccentricity
  (Zeebe, ApJ, 2015).
  
  Mercury's eccentricity and inclination vary with large
  amplitude (max e > 0.87 and growing), which can ultimately
  lead to close encounters with Venus. The integration
  requires a small timestep to avoid numerical chaos. 
  
*/

/*==================== Input Section =========================*/

 /* set time step (days), t0, tend (days), save interval (steps) */
 /* Y2D = 365.25 (years -> days)                                 */
 const double in_dt =  0.125;
 double       in_t0 =  0.e3*Y2D;
 double     in_tend =  70.e3*Y2D;
 const int in_sstep =  73050;

/*============================================================*/