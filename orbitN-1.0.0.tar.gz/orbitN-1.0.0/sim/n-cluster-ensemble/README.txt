#=============================================================#
   
   README.TXT

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com

#=============================================================#

Simulate solar system with initial conditions from DE441.
Run n cluster-ensemble with offsets in the Earth-Moon barycenter 
initial coordinates.

User needs to edit the shell scripts and adjust directories,
settings, etc. to the local environment and the simulation.

Make sure:

- All scripts have executable permission, e.g.,
  $ chmod +x ./kickNodes etc.
  or to activate all: run sim/actvtScripts

- ssh works on and between machines without password, e.g., in
  ~/.ssh/ generate rsa key, add to authorized_keys

Including cleanup of files from previous runs, the order of
execution is:

./compile
./cleanCoords
./makeCoords
./cleanNodes
./kickNodes

./kickNodes copies and kicks off runMe for each job $j in directory
/dat/run.N/R$j on each node.



