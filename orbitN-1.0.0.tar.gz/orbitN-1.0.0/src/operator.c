/***************************************************************

   orbitN VERSION: 1.0.0 (05/2023)
   file: operator.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2023 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   updates:

   03/04/23

   TODO:

***************************************************************/
#include <stdio.h>
#include "orbitN.h"
#include "utils.h"

/*============================================================*/
/*===================== fkepstmpff() =========================*/
/*============================================================*/
void fkepstmpff(double *gg, double *nri, const double nr0, const double u, 
                  const double zeta, const double etaj,
                  const double dt, const double beta, const double s0)
{
#define NMAX_KEP_STMPFF 48 /* 48 20 50 */

 int newtonfail = 1;
 int secantfail = 1;
 int n;
 double s=s0,sold1=NAN,sold2=NAN,f;
 char mssg[BUFSIZ];

 /* compute root using Newton-Raphson. */
 for(n=1;n<=NMAX_KEP_STMPFF;n++){
   sold2 = sold1;
   sold1 = s;
   /* stumpff's c's and g's */
   fgkstumpff(gg,beta,s);

   /* f(s) and deriv f'(s) */
   const double tmp = u*gg[1] + zeta*gg[2];
   //double fpi = 1./(nr0 + tmp);
  *nri = 1./(nr0 + tmp);
   s   = (s*tmp - u*gg[2] - zeta*gg[3] + dt)*(*nri);

   if(s == sold1 || s == sold2){
      newtonfail = 0;
      break;
   }
 }

 /* if Newton failed, try secant method */
 #define SECANT
 #define NMAX_SECANT 16
 if(newtonfail){
 #ifdef SECANT
    if(s != s0){
      double x0 = s0;
      double x1 = s0 + (s - s0)*2.;
      fgkstumpff(gg,beta,x0);
      double f0 = nr0*x0 + u*gg[2] + zeta*gg[3] - dt; 
      fgkstumpff(gg,beta,x1);
      double f1 = nr0*x1 + u*gg[2] + zeta*gg[3] - dt; 

      for(n=1;n<=NMAX_SECANT;n++){
          double x = (x0*f1 - x1*f0)/(f1 - f0);
          if(x == x1 || f1 == f0){
             secantfail = 0;
             break;
          }
          fgkstumpff(gg,beta,x);
          double f = nr0*x + u*gg[2] + zeta*gg[3] - dt;
          x0 = x1;
          f0 = f1;
          x1 = x;
          f1 = f;
      } 
      /* update nri */
      const double tmp = u*gg[1] + zeta*gg[2];
      *nri = 1./(nr0 + tmp);
    } /* if s != s0 END */          
 #endif //SECANT

    /* if secant method failed, try bisection, 
       see rebound integrator_whfast.c        */
    #define NMAX_BISEC 128
    if(secantfail){
       double s_min, s_max;
       const double sqrt_beta = sqrt(beta);
       const double invperiod = sqrt_beta*beta/(2.*PI*etaj);
       const double s_per_period = 2.*PI/sqrt_beta;
       s_min = s_per_period * floor(dt*invperiod);
       s_max = s_min + s_per_period;
       s = (s_max + s_min)/2.;
       n = 0;
       do{
          fgkstumpff(gg,beta,s);
          f  = nr0*s + u*gg[2] + zeta*gg[3] - dt;
          if (f >= 0.){
              s_max = s;
          }else{
              s_min = s;
          }
          s = (s_max + s_min)/2.;
          n++;
          if(n >= NMAX_BISEC){
             sprintf(mssg,"fkepstmpff(): Newton, secant & bisection failed.");
             ferrx(mssg);
          }
      }while(fabs((s_max-s_min)) > fabs((s_max+s_min)*1e-15));
      /* update nri */   
      const double tmp = u*gg[1] + zeta*gg[2];
      *nri = 1./(nr0 + tmp);    
       
    } /* if secantfail END */    
 } /* if newtonfail END */
 
}
/*============================================================*/
/*===================== fkepstmpff() END =====================*/
/*============================================================*/

/* 1/factorials for Stumpff functions */
#define NMAXFACT 13
const double fci[NMAXFACT+1] = \
{1., \
 1., \
 1./2., \
 1./6., \
 1./24., \
 1./120., \
 1./720., \
 1./5040., \
 1./40320., \
 1./362880., \
 1./3628800., \
 1./39916800., \
 1./479001600., \
 1./6227020800.};

/*============================================================*/
/*===================== fgkstumpff() =========================*/
/*============================================================*/
/*
  Evaluation of Stumpff functions follows Mikkola 97, 
  Mikkola & Innanen 98, Mikkola & Aarseth 98, and Rein
  & Tamayo 2015, see rebound integrator_whfast.c
*/
void fgkstumpff(double *cc, double beta, double s)
{
 int n=0,m,np; 
 const double s2=s*s;
 double x=beta*s2;

 /* reduce x recursively by *1/4, see Appendix Mikkola & Aarseth 98 */
 while(fabs(x) > 0.1){
        x = x/4.;
        n++;
 }

 /*
   For systems with large range in x, REDUCE speeds up
   the calculation. Unnecessary for accurate geo-astro runs.    
 */
#define UREDUCE 
#ifdef REDUCE
 int nmax = NMAXFACT;
 if(x < 1.e-9){
   nmax = 5;
 }else 
 if(x < 1.e-6){ 
   nmax = 7;
 }else 
 if(x < 1.e-4){
   nmax = 9;
 }else
 if(x < 1.e-3){
   nmax = 11;
 }
#else
 const int nmax = NMAXFACT;
#endif

 double c_odd  = fci[nmax];
 double c_even = fci[nmax-1];
 for(np=nmax-2;np>=3;np-=2){
     c_odd  = fci[np]   - x*c_odd;
     c_even = fci[np-1] - x*c_even;
 }
 cc[3] = c_odd;
 cc[2] = c_even;
 cc[1] = fci[1]  - x*c_odd;
 cc[0] = fci[0]  - x*c_even;
    
 /* recover c's for original x, see Appendix Mikkola & Aarseth 98 */
 for(m=n;m>0;m--){
     cc[3] = (cc[2]+cc[0]*cc[3])*0.25;
     cc[2] = cc[1]*cc[1]*0.5;
     cc[1] = cc[0]*cc[1];
     cc[0] = 2.*cc[0]*cc[0]-1.; // not used ???
 }
 
 /* next, actually G-funcions (Mikkola & Innanen 98, Eq. 9) */
 cc[1] *= s;
 cc[2] *= s2;
 cc[3] *= s2*s;

}
/*============================================================*/
/*===================== fgkstumpff() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fgdrift() ============================*/
/*============================================================*/
void fgdrift(double **xx, double **vv, double **dxx, double **dvv,
             double dt, double *eta, const double c2i, const int jmax,
             int khn)
{
 int j;
 double etaj,nr0,dotv0,u,beta,zeta,s0;
 double nri,nr0i;
 double gg[3+1];
#ifdef PN
 const double dt0=dt;
#else
 UNUSED(c2i);
#endif  

 /* loop over bodies j>0 */
 for(j=1;j<=jmax;j++){

  etaj = eta[j];
   nr0 = sqrt(xx[j][1]*xx[j][1]+xx[j][2]*xx[j][2]+xx[j][3]*xx[j][3]);
 dotv0 =      vv[j][1]*vv[j][1]+vv[j][2]*vv[j][2]+vv[j][3]*vv[j][3];
     u =      xx[j][1]*vv[j][1]+xx[j][2]*vv[j][2]+xx[j][3]*vv[j][3];
//double nv0 = sqrt(dotv0);
  nr0i = 1./nr0;
  beta = 2.*etaj*nr0i - dotv0;	 
  zeta = etaj - beta*nr0;

#ifdef PN
  /* post-newton: ST94 scale dt */
  //mu = k2*msumj[j]; // = etaj
  //a = 1./(2./nr0 - dotv0/etaj);
  //a = etaj/beta;
  //const double ai = beta/etaj;
  //dt = dt0*(1. - 1.5*k2*msumj[j]*ai*c2i); 
  //dt = dt0*(1. - 1.5*etaj*ai*c2i); 
  dt = dt0*(1. - 1.5*beta*c2i);
#endif
 
  /* s0 2nd order guess quicker and more accurate. Danby 87 Eq. 18 */   
  s0 = dt*nr0i*(1. - 0.5*dt*u*nr0i*nr0i);

  /* s0 guess Danby 88 (no good) */
  //s0 = dt*nr0i; //- dt*dt*nv0/(2.*nr0*nr0); // only small dt

  /* kepler stumpff solver */
  fkepstmpff(gg,&nri,nr0,u,zeta,etaj,dt,beta,s0);  

  /* hat f and g */
  const double fh = -etaj*gg[2]*nr0i;	 
  const double g  =  dt - etaj*gg[3];
  /* fdot and hat gdot */
  const double fdot  = -etaj*gg[1]*nr0i*nri;
  const double gdoth = -etaj*gg[2]*nri;

  /* drift deltas dx, dv */
  dxx[j][1] =   fh*xx[j][1] +     g*vv[j][1];
  dxx[j][2] =   fh*xx[j][2] +     g*vv[j][2];
  dxx[j][3] =   fh*xx[j][3] +     g*vv[j][3];

  dvv[j][1] = fdot*xx[j][1] + gdoth*vv[j][1];
  dvv[j][2] = fdot*xx[j][2] + gdoth*vv[j][2];
  dvv[j][3] = fdot*xx[j][3] + gdoth*vv[j][3];

  if(khn == 0){
     /* update x, v */
     xx[j][1] += dxx[j][1];
     xx[j][2] += dxx[j][2];
     xx[j][3] += dxx[j][3];
     vv[j][1] += dvv[j][1];
     vv[j][2] += dvv[j][2];
     vv[j][3] += dvv[j][3];
  }

 } /* END loop over bodies j>0 */

}
/*============================================================*/
/*===================== fgdrift() END ========================*/
/*============================================================*/

/*============================================================*/
/*===================== fparm_lunar() ========================*/
/*============================================================*/
/*
   see hnbody driver lunar.c
*/
double fparm_lunar(double t, const double k2)
{
 UNUSED(t);

 /* F_LUNAR: defined in orbitN.h. rem = Eearth-Moon distance */
 const double f = F_LUNAR;
 double rem = 0.0025696;

 return(0.25*k2*rem*rem*f/(2.+81.3007+1./81.3007));

}
/*============================================================*/
/*===================== fparm_lunar() END ====================*/
/*============================================================*/

/*============================================================*/
/*===================== fkick_lunar() ========================*/
/*============================================================*/
/*
   see hnbody driver lunar.c
*/
void fkick_lunar(double **xx, double aa[][CDIM], double dt, double *m,
                 const double k2)
{
 UNUSED(dt);
 const double x1 = xx[3][1] - xx[0][1]; 
 const double x2 = xx[3][2] - xx[0][2]; 
 const double x3 = xx[3][3] - xx[0][3]; 

 const double ri=1./sqrt(x1*x1+x2*x2+x3*x3);
 const double fac=3.*fparm_lunar(0.,k2)*ri*ri*ri*ri*ri;

 aa[3][1] -= fac*m[0]*x1;
 aa[3][2] -= fac*m[0]*x2;
 aa[3][3] -= fac*m[0]*x3;

 aa[0][1] += fac*m[3]*x1;
 aa[0][2] += fac*m[3]*x2;
 aa[0][3] += fac*m[3]*x3;

}
/*============================================================*/
/*===================== fkick_lunar() END ====================*/
/*============================================================*/

/*============================================================*/
/*===================== fkick() ==============================*/
/*============================================================*/
/*
   basic gravity routine follows ReinTamayo15. For J2 and
   PN, see orbitN paper.
*/
void fkick(double **xx, double **vv, double **dxx, double **dvv,
           double dt, double **xn, double *m, double *msumj,
           const double k2, const double c2i, const int jmax,
           int khn)
{
 int j,k;
 double aa[NMAX][CDIM];
 const double m0=m[0];
 double msum=m0,tmp[3+1];
#ifdef J2 /* solar quadrupole moment */
 const double aj2 = AJ2C;
#endif

 /* dxx: no need to set to zero. unused in fkahan_v(), reset in fgdrift() */
 UNUSED(dxx);
 if(khn)
    UNUSED(vv);

 /* all accelerations to zero */
 for(j=0;j<=jmax;j++){
     aa[j][1] = 0.; 
     aa[j][2] = 0.; 
     aa[j][3] = 0.;
 }

 /* get inertia positions -> xn */
 fjac2inert_x(xn,xx,m,msumj,jmax);

#ifdef J2 /*========= J2 =========*/
 double fac,fackxy,facjxy,fackz,facjz;
 /* interaction terms in inertia xn. jk=01 cancels with Jac term below */
 for(j=0;j<=jmax-1;j++){
     for(k=j+1;k<=jmax;k++){ /* BUT for J2: start k=j+1 for all j */
         const double rx = xn[j][1] - xn[k][1];
         const double ry = xn[j][2] - xn[k][2];
         const double rz = xn[j][3] - xn[k][3];
         const double nr = sqrt(rx*rx + ry*ry + rz*rz);
         const double nr3 = nr*nr*nr;
         if(k == 1){ /* k=1: only J2 here (primary grav term cancels) */ 
            fac = 0.;
         } else {
            fac = k2/nr3;
         }
         if(j == 0){ /* include J2 for k and central j=0 */
            const double r2i  = 1./(nr*nr);
            const double r5i  = r2i/nr3;
            const double cr2i = 5.*rz*rz*r2i;
            const double cr5i = 3.*aj2*r5i;
            const double aj2xy = cr5i*(cr2i - 1.);
            const double aj2z  = cr5i*(cr2i - 3.);
            fackxy = (-fac+aj2xy)*m[k];
            fackz  = (-fac+aj2z )*m[k];
            facjxy =  (fac-aj2xy)*m[j]; // m[j] = m[0]
            facjz  =  (fac-aj2z )*m[j]; // m[j] = m[0]
            aa[j][1] += fackxy*rx;
            aa[j][2] += fackxy*ry;
            aa[j][3] += fackz*rz;
            aa[k][1] += facjxy*rx;
            aa[k][2] += facjxy*ry;
            aa[k][3] += facjz*rz;
         } else { /* j>0, k>1 (fac[k=1]=0) jk mutual interactions */
            const double fack = -fac*m[k];
            const double facj =  fac*m[j];
            aa[j][1] += fack*rx;
            aa[j][2] += fack*ry;
            aa[j][3] += fack*rz;
            aa[k][1] += facj*rx;
            aa[k][2] += facj*ry;
            aa[k][3] += facj*rz;
         }
     }
 }

#else /*========= NO J2 =========*/

 int ks;
 /* interaction terms in inertia xn. jk=01 cancels with Jac term below */ 
 for(j=0;j<=jmax-1;j++){
     if(j == 0) ks = 2; else ks = j+1; /* hence start k=2 for j=0 */
     for(k=ks;k<=jmax;k++){
         const double rx = xn[j][1] - xn[k][1];
         const double ry = xn[j][2] - xn[k][2];
         const double rz = xn[j][3] - xn[k][3];
         const double nr = sqrt(rx*rx + ry*ry + rz*rz);
         const double fac  = k2/(nr*nr*nr);
         const double fack = -fac*m[k];
         const double facj =  fac*m[j];
         aa[j][1] += fack*rx;
         aa[j][2] += fack*ry;
         aa[j][3] += fack*rz;
         aa[k][1] += facj*rx;
         aa[k][2] += facj*ry;
         aa[k][3] += facj*rz;
     }
 }

#endif /*========= J2 =========*/

#ifdef LUNAR
 fkick_lunar(xn,aa,dt,m,k2);
#endif
 
 /* transform accelerations to Jacobi coords */ 
 finert2jac_a(aa,m,msumj,jmax);
 
#ifdef PN /*========= PN =========*/

 double facj;
 /* update dvv or vv and add Jacobi term */
 for(j=1;j<=jmax;j++){
     msum += m[j];
     dvv[j][1] = dt*aa[j][1];
     dvv[j][2] = dt*aa[j][2];
     dvv[j][3] = dt*aa[j][3];
     if(khn == 0){
        /* update v */
        vv[j][1] += dvv[j][1];
        vv[j][2] += dvv[j][2];
        vv[j][3] += dvv[j][3];
     }
     const double r2ijac = 1./SQR(xx[j]);
     if(j > 1){ /* j=0 cancels with jk=01 term above */
        const double rijac  = sqrt(r2ijac);
        const double rkmjac = rijac*r2ijac*k2*msum;
        facj = dt*rkmjac;
     } else {
        facj = 0.;
     }
     double mu = k2*msumj[j];
     //double beta = -mu*mu/c2; /* mj in beta and vj=pj/mj cancel */
     double facpn = -dt*2.*mu*mu*r2ijac*r2ijac*c2i;
     
     facj += facpn;
     tmp[1] = facj*xx[j][1];
     tmp[2] = facj*xx[j][2];
     tmp[3] = facj*xx[j][3];
     dvv[j][1] += tmp[1];
     dvv[j][2] += tmp[2];
     dvv[j][3] += tmp[3];
     if(khn == 0){
        /* update v */
        vv[j][1] += tmp[1];
        vv[j][2] += tmp[2];
        vv[j][3] += tmp[3];
     }
 }

#else /*========= No PN =========*/

  UNUSED(c2i);
 /* update dvv or vv and add Jacobi term */
 for(j=1;j<=jmax;j++){
     msum += m[j];
     dvv[j][1] = dt*aa[j][1];
     dvv[j][2] = dt*aa[j][2];
     dvv[j][3] = dt*aa[j][3];
     if(khn == 0){
        /* update v */
        vv[j][1] += dvv[j][1];
        vv[j][2] += dvv[j][2];
        vv[j][3] += dvv[j][3];
     }
     if(j > 1){ /* j=0 cancels with jk=01 term above */
        const double r2ijac = 1./SQR(xx[j]);
        const double rijac   = sqrt(r2ijac);
        const double rkmjac  = rijac*r2ijac*k2*msum;
        const double facnopn = dt*rkmjac;
        tmp[1] = facnopn*xx[j][1];
        tmp[2] = facnopn*xx[j][2];
        tmp[3] = facnopn*xx[j][3];
        dvv[j][1] += tmp[1];
        dvv[j][2] += tmp[2];
        dvv[j][3] += tmp[3];
        if(khn == 0){
           /* update v */
           vv[j][1] += tmp[1];
           vv[j][2] += tmp[2];
           vv[j][3] += tmp[3];
        }
     }
 }
#endif /*========= PN =========*/

}
/*============================================================*/
/*===================== fkick() END ==========================*/
/*============================================================*/

//#ifdef PN
/*============================================================*/
/*===================== fpn_gam_half() =======================*/
/*============================================================*/
/* Post-Newton: ST94 gamma term 1/2 dt0                       */

void fpn_gam_half(double **xx, double **vv, double **dxx,
                  double dt, const double c2i, const int jmax)
{
 int j;
 const double dtc2i=-dt*c2i;

 for(j=1;j<=jmax;j++){
   const double v2 = vv[j][1]*vv[j][1]+vv[j][2]*vv[j][2]+vv[j][3]*vv[j][3];
   //double fac = -0.5*dt0*2.*v2*c2i; // 0.5 from 1/2 step
   //fac = -dt*v2*c2i;
   const double fac = dtc2i*v2;
#ifdef KAHAN
   UNUSED(xx);
   dxx[j][1] = fac*vv[j][1];
   dxx[j][2] = fac*vv[j][2];
   dxx[j][3] = fac*vv[j][3];
#else
   UNUSED(dxx);
   xx[j][1] += fac*vv[j][1];
   xx[j][2] += fac*vv[j][2];
   xx[j][3] += fac*vv[j][3];
#endif
 }

}
/*============================================================*/
/*===================== fpn_gam_half() END ===================*/
/*============================================================*/
//#endif

/*============================================================*/
/*=========== macros & const for corrector fcorr() ===========*/
/*============================================================*/
/* see Wisdom (2006)                                          */

/* Note: final argument = khn = 0 for corrector calls */
#define DRFT(h) fgdrift(xx,vv,dxx,dvv,h,eta,c2i,jmax,0)
#define KICK(h)   fkick(xx,vv,dxx,dvv,h,xb,m,msumj,k2,c2i,jmax,0)

/* CMD ORDER/SIGN IS REVERSE TO OPERATOR ! */
#define ZZ(ah,bh) { DRFT(ah); KICK(-bh); DRFT(-2.*ah); KICK(bh); DRFT(ah);}

//#define CC_RCNT /* recent compilers */
#ifdef CC_RCNT
//const double alp = sqrt(7./40.);
const double alp = 0.41833001326703777398908601289259;
const double bet = (1./(48.*alp));
/* stage 2 corrector */
const double a1_two = -alp,
             a2_two =  alp,     \
             b1_two = -0.5*bet, \
             b2_two =  0.5*bet;
/* stage 4 corrector */
const double a1_four =   2.*alp,  \
             a2_four =      alp,  \
             a3_four = -a2_four,  \
             a4_four = -a1_four,  \
             b1_four =   -bet/6., \
             b2_four = 5.*bet/6., \
             b3_four = -b2_four,  \
             b4_four = -b1_four;
/* stage 6 corrector */
const double a1_six =  3.*alp, \
             a2_six =  2.*alp, \
             a3_six =     alp, \
             a4_six = -a3_six, \
             a5_six = -a2_six, \
             a6_six = -a1_six, \
             /**
             b1_six =  (12361./246960.)*bet, \
             b2_six = -(22651./61740.)*bet,  \
             b3_six =  (53521./49392.)*bet,  \
             **/
             b1_six =  12361.*bet/246960., \
             b2_six = -22651.*bet/61740.,  \
             b3_six =  53521.*bet/49392.,  \
             /**/
             b4_six = -b3_six, \
             b5_six = -b2_six, \
             b6_six = -b1_six;

#else /* old compilers. numbers: quad precision */

/* stage 2 corrector */
const double \
a1_two = -0.41833001326703777398908601289259, \
a2_two =  0.41833001326703777398908601289259, \
b1_two = -0.02490059602779986749935035791027, \
b2_two =  0.02490059602779986749935035791027;
/* stage 4 corrector */
const double \
a1_four =  0.83666002653407554797817202578519, \
a2_four =  0.41833001326703777398908601289259, \
a3_four = -0.41833001326703777398908601289259, \
a4_four = -0.83666002653407554797817202578519, \
b1_four = -0.00830019867593328916645011930342, \
b2_four =  0.04150099337966644583225059651712, \
b3_four = -0.04150099337966644583225059651712, \
b4_four =  0.00830019867593328916645011930342;
/* stage 6 corrector. old != recent. delta ~= eps !!! */
const double \
a1_six =  1.25499003980111332196725803867778, \
a2_six =  0.83666002653407554797817202578519, \
a3_six =  0.41833001326703777398908601289259, \
a4_six = -0.41833001326703777398908601289259, \
a5_six = -0.83666002653407554797817202578519, \
a6_six = -1.25499003980111332196725803867778, \
b1_six =  0.00249268114269221057790305939528, \
b2_six = -0.01827092324670213147806235688454, \
b3_six =  0.05396439909312749872176589349351, \
b4_six = -0.05396439909312749872176589349351, \
b5_six =  0.01827092324670213147806235688454, \
b6_six = -0.00249268114269221057790305939528;

#endif /* CC_RCNT */

/*============================================================*/
/*===================== fcorr() ==============================*/
/*============================================================*/
void fcorr(double **xx, double **vv, double **dxx, double **dvv,
           double **xb, double dt, double *m, double *msumj,
           double *eta, const double k2, const double c2i,
           const int jmax, int inv, const int stage){

 /* stage 2 corrector */
 if(stage == 2){
  if(inv == 0){      /* corrector */
   ZZ(a2_two*dt,b2_two*dt);
   ZZ(a1_two*dt,b1_two*dt);
  } else {          /* inverse corrector */
   ZZ(a1_two*dt,-b1_two*dt);
   ZZ(a2_two*dt,-b2_two*dt);
  }
 }

 /* stage 4 corrector */
 if(stage == 4){
  if(inv == 0){      /* corrector */
   ZZ(a4_four*dt,b4_four*dt);
   ZZ(a3_four*dt,b3_four*dt);
   ZZ(a2_four*dt,b2_four*dt);
   ZZ(a1_four*dt,b1_four*dt);
  } else {          /* inverse corrector */
   ZZ(a1_four*dt,-b1_four*dt);
   ZZ(a2_four*dt,-b2_four*dt);
   ZZ(a3_four*dt,-b3_four*dt);
   ZZ(a4_four*dt,-b4_four*dt);
  }
 }

 /* stage 6 corrector */
 if(stage == 6){
  if(inv == 0){      /* corrector */
   ZZ(a6_six*dt,b6_six*dt);
   ZZ(a5_six*dt,b5_six*dt);
   ZZ(a4_six*dt,b4_six*dt);
   ZZ(a3_six*dt,b3_six*dt);
   ZZ(a2_six*dt,b2_six*dt);
   ZZ(a1_six*dt,b1_six*dt);
  } else {          /* inverse corrector */
   ZZ(a1_six*dt,-b1_six*dt);
   ZZ(a2_six*dt,-b2_six*dt);
   ZZ(a3_six*dt,-b3_six*dt);
   ZZ(a4_six*dt,-b4_six*dt);
   ZZ(a5_six*dt,-b5_six*dt);
   ZZ(a6_six*dt,-b6_six*dt);
  }
 }

}
/*============================================================*/
/*===================== fcorr() END ==========================*/
/*============================================================*/

/*============================================================*/
/*===================== fkahan() =============================*/
/*============================================================*/
/*
 Kahan compensated summation. cx, cv = low order bits
*/
void fkahan(double **xx, double **vv, double **cx, double **cv,
            double **dxx, double **dvv, const int jmax, int flag)
{
 int j;

 if(flag){
  for(j=1;j<=jmax;j++){
    //
    const double yx1 = dxx[j][1] - cx[j][1];
    const double yx2 = dxx[j][2] - cx[j][2];
    const double yx3 = dxx[j][3] - cx[j][3];
    const double yv1 = dvv[j][1] - cv[j][1];
    const double yv2 = dvv[j][2] - cv[j][2];
    const double yv3 = dvv[j][3] - cv[j][3];
    //
    const double tx1 =  xx[j][1] + yx1;
    const double tx2 =  xx[j][2] + yx2;
    const double tx3 =  xx[j][3] + yx3;
    const double tv1 =  vv[j][1] + yv1;
    const double tv2 =  vv[j][2] + yv2;
    const double tv3 =  vv[j][3] + yv3;
    //
    cx[j][1] = (tx1 - xx[j][1]) - yx1;
    cx[j][2] = (tx2 - xx[j][2]) - yx2;
    cx[j][3] = (tx3 - xx[j][3]) - yx3;
    cv[j][1] = (tv1 - vv[j][1]) - yv1;
    cv[j][2] = (tv2 - vv[j][2]) - yv2;
    cv[j][3] = (tv3 - vv[j][3]) - yv3;
    //
    xx[j][1] =  tx1;
    xx[j][2] =  tx2;
    xx[j][3] =  tx3;
    vv[j][1] =  tv1;
    vv[j][2] =  tv2;
    vv[j][3] =  tv3;

  }
 } /* flag END */

}
/*============================================================*/
/*===================== fkahan() END =========================*/
/*============================================================*/

/*============================================================*/
/*===================== fkahan_x() ===========================*/
/*============================================================*/
/*
 Kahan compensated summation x only. cx = low order bits
*/
void fkahan_x(double **xx, double **cx, double **dxx, 
              const int jmax, int flag)
{
 int j;

 if(flag){
  for(j=1;j<=jmax;j++){
    //
    const double yx1 = dxx[j][1] - cx[j][1];
    const double yx2 = dxx[j][2] - cx[j][2];
    const double yx3 = dxx[j][3] - cx[j][3];
    //
    const double tx1 =  xx[j][1] + yx1;
    const double tx2 =  xx[j][2] + yx2;
    const double tx3 =  xx[j][3] + yx3;
    //
    cx[j][1] = (tx1 - xx[j][1]) - yx1;
    cx[j][2] = (tx2 - xx[j][2]) - yx2;
    cx[j][3] = (tx3 - xx[j][3]) - yx3;
    //
    xx[j][1] =  tx1;
    xx[j][2] =  tx2;
    xx[j][3] =  tx3;

  }
 } /* flag END */

}
/*============================================================*/
/*===================== fkahan_x() END =======================*/
/*============================================================*/

/*============================================================*/
/*===================== fkahan_v() ===========================*/
/*============================================================*/
/*
 Kahan compensated summation v only. cv = low order bits
*/
void fkahan_v(double **vv, double **cv, double **dvv,
              const int jmax, int flag)
{
 int j;

 if(flag){
  for(j=1;j<=jmax;j++){
    //
    const double yv1 = dvv[j][1] - cv[j][1];
    const double yv2 = dvv[j][2] - cv[j][2];
    const double yv3 = dvv[j][3] - cv[j][3];
    //
    const double tv1 =  vv[j][1] + yv1;
    const double tv2 =  vv[j][2] + yv2;
    const double tv3 =  vv[j][3] + yv3;
    //
    cv[j][1] = (tv1 - vv[j][1]) - yv1;
    cv[j][2] = (tv2 - vv[j][2]) - yv2;
    cv[j][3] = (tv3 - vv[j][3]) - yv3;
    //
    vv[j][1] =  tv1;
    vv[j][2] =  tv2;
    vv[j][3] =  tv3;

  }
 } /* flag END */

}
/*============================================================*/
/*===================== fkahan_v() END =======================*/
/*============================================================*/
