/***************************************************************

   orbitN VERSION: 1.0.0 (05/2023)
   file: energyangm.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2023 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   updates:

   03/04/23

   TODO:

***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "orbitN.h"
#include "utils.h"

/*============================================================*/
/*===================== fenergy() ============================*/
/*============================================================*/
/*
 Proper input for energy calculation is barycentrics: flag = 0
 If input is Jacobi coords,  convert to barycentrics: flag = 1
 (main loop uses Jacobi)
*/
double fenergy(double **xx, double **vv, struct masses m,
               const double k2, const double c2, const int jmax,
               int flag)
{
 extern double **x_,**v_; /* memory dummies */
 int j,k;
 double **xb=x_,**vb=v_,*x0,*v0,*x,*v,nr,nv,*xk,mk;
 double r[3+1];
 double e1=0.,e2=0.,e3=0.,e=0.;
 char mssg[BUFSIZ];

 /* init barycentrics for transform. do not overwrite **xx **vv */

 if(flag == 0)  /* input is bary, make copy */
    fcopyxv(xb,vb,xx,vv,jmax);
 if(flag == 1) /* input is jac, convert to bary */
    fjac2inert(xb,vb,xx,vv,m.m,m.msumj,jmax);
 if(flag < 0 || flag > 1){
    sprintf(mssg,"fenergy(): set flag = 0 or 1 (bary or jac input)");
	ferrx(mssg);
 }

#ifdef PN
 /* calc post-newton pn energy. Ekin and pn terms are    */
 /* calculated using pseudo velocities and jacobi coords */
 extern double **x__,**v__; /* memory dummies */
 double **xj=x__,**vj=v__;
 finert2jac(xj,vj,xb,vb,m.m,m.msumj,jmax);
 /* for PN vb = vpseudo */
 fjac2pseudo_v(vb,xj,vj,m,k2,c2,jmax);
#else
 UNUSED(c2);
#endif

/* central body */
 x0 = xb[0];
#ifdef PN
 v0 = vj[0];
#else
 v0 = vb[0];
#endif
 nv = sqrt(v0[1]*v0[1]+v0[2]*v0[2]+v0[3]*v0[3]);
 e1 = 0.5*m.m[0]*nv*nv;	
	
 /* E-kinetic and potential j>0 */
 for(j=1;j<=jmax;j++){
  /* pointer to xb and vb rows => x and v vector of body j */
  x = xb[j];	 
  v = vb[j];
  nv = sqrt(v[1]*v[1]+v[2]*v[2]+v[3]*v[3]);
  /* E-potential between central body and bodies j>0 */
  r[1] = x[1] - x0[1];
  r[2] = x[2] - x0[2];
  r[3] = x[3] - x0[3];	 
  nr = sqrt(r[1]*r[1]+r[2]*r[2]+r[3]*r[3]);
#ifdef PN
  mk = m.mj[j];
#else
  mk = m.m[j];
#endif  
  /* subtract numbers of similar order */
  e2 += (0.5*mk*nv*nv - k2*m.m[0]*m.m[j]/nr);
 }

 /* E-potential between all bodies j>0 */
 for(j=1;j<=jmax;j++){
    for(k=j;k<=jmax;k++){
       if(k != j){
            x  = xb[j];
            xk = xb[k];
          r[1] = xk[1] - x[1];
          r[2] = xk[2] - x[2];
          r[3] = xk[3] - x[3];	 
          nr = sqrt(r[1]*r[1]+r[2]*r[2]+r[3]*r[3]);
          e3 -= k2*m.m[j]*m.m[k]/nr;
       }
	}
 }
 
#ifdef PN
 /* add post-newton energy */
 double mu,v2,epn=0.;
 for(j=1;j<=jmax;j++){
   mu = k2*m.msumj[j];
   //mu = k2*m.msumj[j]/m.msumj[j-1]; // ST94
   nr = sqrt(xj[j][1]*xj[j][1]+xj[j][2]*xj[j][2]+xj[j][3]*xj[j][3]);
   v2 =      vb[j][1]*vb[j][1]+vb[j][2]*vb[j][2]+vb[j][3]*vb[j][3];
   epn += m.mj[j]*(0.5*mu*mu/(nr*nr) - 0.125*v2*v2 - 1.5*mu*v2/nr);
 }
 epn /= c2;
 e3 += epn;
#endif

#ifdef J2
 /* add solar quadrupole energy */
 double ej2 = 0.; 
 const double aj2 = AJ2C;
 const double m0 = m.m[0];
 for(j=1;j<=jmax;j++){
  const double mj = m.m[j];
  /* pointer to xb rows => x vector of body j */
  x = xb[j];	 
  /* J2 potential between central body and bodies j>0 */
  const double rx = x[1] - x0[1];
  const double ry = x[2] - x0[2];
  const double rz = x[3] - x0[3];	 
  const double r2i = 1./(rx*rx + ry*ry + rz*rz);
  const double ri  = sqrt(r2i);
  ej2 += aj2*mj*m0*r2i*ri*(3.*rz*rz*r2i - 1.);
 } 
 e3 += ej2;
#endif

#ifdef LUNAR
 e3 += ferg_lunar(xb,m.m,k2);
#endif

 /* |e2| > |e1| > |e3| */
 e = e1 + e2 + e3;

 return(e);

}
/*============================================================*/
/*===================== fenergy() END ========================*/
/*============================================================*/

/*============================================================*/
/*===================== ferg_lunar() =========================*/
/*============================================================*/
/*
   see hnbody driver lunar.c
*/
double ferg_lunar(double **xx, double *m, const double k2)
{
/*
   energy due to fkick_lunar().
*/

  double x1 = xx[3][1] - xx[0][1];
  double x2 = xx[3][2] - xx[0][2];
  double x3 = xx[3][3] - xx[0][3];
	 
  double ri = 1./sqrt(x1*x1+x2*x2+x3*x3);
  double fac = -m[0]*m[3]*fparm_lunar(0.,k2)*ri*ri*ri;

  return(fac);
}
/*============================================================*/
/*===================== ferg_lunar() END =====================*/
/*============================================================*/

/*============================================================*/
/*===================== fangm() ==============================*/
/*============================================================*/
/*
 Proper input for angm calculation is barycentrics:  flag = 0
 If input is Jacobi coords, convert to barycentrics: flag = 1
 (main loop uses Jacobi)
*/
void fangm(double *lv, double **xx, double **vv, struct masses m,
           const double k2, const double c2, const int jmax, int flag)
{
 extern double **x_,**v_; /* memory dummies */
 int j;
 double **xb=x_,**vb=v_,l[3+1]={NAN,0.,0.,0.};
 char mssg[BUFSIZ];
 
 /* use xb, vb for transform. do not overwrite **xx **vv */

 if(flag == 0)  /* input is bary, make copy */
    fcopyxv(xb,vb,xx,vv,jmax);
 if(flag == 1) /* input is jac, convert to bary */
    fjac2inert(xb,vb,xx,vv,m.m,m.msumj,jmax);
 if(flag < 0 || flag > 1){
    sprintf(mssg,"fangm(): set flag = 0 or 1 (bary or jac input)");
	ferrx(mssg);
 }

#ifdef PN
 double c2i=1./c2;
 double nr,v2,mu,fac=1.;
 for(j=0;j<=jmax;j++){
     if(j > 0){
       nr = sqrt(xb[j][1]*xb[j][1]+xb[j][2]*xb[j][2]+xb[j][3]*xb[j][3]);
       v2 =      vb[j][1]*vb[j][1]+vb[j][2]*vb[j][2]+vb[j][3]*vb[j][3];
       mu = k2*m.msumj[j];
       //mu = k2*m.msumj[j]/m.msumj[j-1]; // ST94
       fac = 1. + (0.5*v2 + 3.*mu/nr)*c2i;
     }
     l[1] += fac*m.m[j]*(xb[j][2]*vb[j][3] - xb[j][3]*vb[j][2]);
     l[2] += fac*m.m[j]*(xb[j][3]*vb[j][1] - xb[j][1]*vb[j][3]);
     l[3] += fac*m.m[j]*(xb[j][1]*vb[j][2] - xb[j][2]*vb[j][1]);
 }
#else
 UNUSED(k2),UNUSED(c2);
 for(j=0;j<=jmax;j++){
     l[1] += m.m[j]*(xb[j][2]*vb[j][3] - xb[j][3]*vb[j][2]);
     l[2] += m.m[j]*(xb[j][3]*vb[j][1] - xb[j][1]*vb[j][3]);
     l[3] += m.m[j]*(xb[j][1]*vb[j][2] - xb[j][2]*vb[j][1]);
 }
#endif

 lv[1] = l[1];
 lv[2] = l[2];
 lv[3] = l[3];

}
/*============================================================*/
/*===================== fangm() END ==========================*/
/*============================================================*/
