/***************************************************************

   orbitN VERSION: 1.0.0 (05/2023)
   file: xv2elm.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2023 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   read orbitN output x v, write Keplerian elements.

   updates:

   05/17/23 Output Keplerian elements: Case e>=1
   05/08/23 ei_case om, nu: acos -> acos_r
   03/12/23

   TODO:

***************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "orbitN.h"
#include "utils.h"

/*==================== Input Section =========================*/

/* set directories */
#define INNDIR "/dat/OrbitN/ZB18a/std"
#define OUTDIR "."
/* set file names */
#define INNFILE "orbitN-"
#define OUTFILE "orbitN-"
#define INN_EXT "dat"
#define OUT_EXT "elm.dat"

/* macros: this file */
#define J 1         /* No. of Bodies excl. central mass      */
#define M0 1.0      /* central mass                          */
#define _ANG_DEG_   /* output angle units: deg. else: rad    */
#define _ELM_MJ_ 1  /* 0/1 use M0 or M0+mj to calc elements  */
                    /* if set to 0, no input masses needed   */

/*============================================================*/

//#define NMAX 100 /* allocate max #bodies, see orbitN.h */
#define NVAL 7    /* m+x+v values to read */ 

/*============================================================*/
/*===================== freadcoords() ========================*/
/*============================================================*/
/*
  variables to read: m: mass, x: position, v: velocity 
*/
void freadcoords(char *dir, char *foo, int nreq, double *m, 
                 double **x, double **v)
{
 int i,k,l,imax,kmax;
 double **y;
 char *fpstr=dir,mssg[BUFSIZ],line[BUFSIZ];
 char *pch,*eptr;	
 FILE *fp;

 y = dmatrix(1,NMAX,1,NVAL);
	
 /* open coordinate file */
 strcat(fpstr,"/");
 strcat(fpstr,foo);
 fp = fopen(fpstr,"r");
 if(fp == NULL){ 
    sprintf(mssg,"freadcoords(): Can't open coordinate file: '%s'",fpstr);
	ferrx(mssg);
 } 
 else{
    printf("\n@ Reading coordinate file: '%s'\n",fpstr);
 }

 /* read line-by-line, extract vars m, x, v   */
 /* counters: i = bodies, k = vals, l = lines */
 i = k = l = 0;
 i++;
 while(fgets(line, sizeof(line), fp) != NULL){
  l++;
  /* ignore lines including "#" */
  if(!strstr(line,"#")){
   //printf("%s",line);
   /* split into tokens */
   pch = strtok(line," \t\r\n\v\f");
   while(pch != NULL){
     //printf("s= %s\n",pch);
     /* strings to ignore */
     if(!strstr(pch,"\\") && !strstr(pch,"\t")){
        k++;
        /* convert string to double */
        y[i][k] = strtod(pch,&eptr);
        //printf("%.17E %d %d\n",y[i][k],i,k);
#ifdef WARN		 
        if(y[i][k] == 0.0){
          sprintf(mssg,"freadcoords(): Warning reading coordinates '%s'",fpstr);			
          printf("i k l %d %d %d\n",i,k,l);
          printf("%.17E\n",y[i][k]);
          printf("\n+++ Coord input file: Some x0 or v0 are zero.\n");				
          fwarn(mssg);
        }
#endif		 
        if(k == NVAL){ /* all values read */
           i++;
           kmax = k;
           k = 0;
           //printf("i = %d\n",i);		   
        } 
     }
     pch = strtok(NULL," ");
   } // while pch 
  } // if #
 } // while line
 i = i-1; /* -1 for final i++ */
 imax = i;

 /* close file */
 fclose(fp);
	
 if((imax < 1) || (k != 0) || kmax != NVAL){
   sprintf(mssg,"freadcoords(): Error reading coordinates '%s'",fpstr);
   printf("i k l = %d %d %d\n",i,k,l);	
   printf("imax kmax l = %d %d %d\n",imax,kmax,l);	
   printf("\n+++ Coord input file: Try removing spaces after '\\'\n");	
   ferrx(mssg);
 }

 /* extract variables from y */
 for(i=1;i<=nreq;i++){
     m[i]    = y[i][1];
     x[i][1] = y[i][2];
     x[i][2] = y[i][3];
     x[i][3] = y[i][4];
     v[i][1] = y[i][5];
     v[i][2] = y[i][6];
     v[i][3] = y[i][7];
 }

 printf("@ Done reading coordinates of %d bodies (excl. central mass).\n",imax);	
 printf("@ Requested: %d\n\n",nreq);	
 if(nreq > imax){
   printf("Bodies requested > Bodies read.");	
   sprintf(mssg,"freadcoords(): Error reading coordinates '%s'",fpstr);
   ferrx(mssg);
 }
	
 free_dmatrix(y,1,NMAX,1,NVAL);

}
/*============================================================*/
/*===================== freadcoords() END ====================*/
/*============================================================*/

/*============================================================*/
/*======== fget_eccvec() & fmean_anomaly() & acos_r() ========*/
/*============================================================*/
/*
  calculate ecc vector ev, norm ee
*/
void fget_eccvec(double *ev, double *ee, double *x, double *v, 
                 double *hv, double ri, double eta0i)
{
 double u[CDIM];
 vcross(u,v,hv);
 vsclr(ev,eta0i,u,3);
 ev[1] -= x[1]*ri;
 ev[2] -= x[2]*ri;
 ev[3] -= x[3]*ri;
 *ee = NORM(ev);
}
/*============================================================*/
/*============================================================*/
/*
  calculate mean anomaly from true anomaly
*/
double fmean_anomaly(double e, double nu)
{
 double mn=0.;
 if(e < 1.0){                       /* elliptical */
    double zi = sqrt((1.-e)/(1.+e));
    /* calc ecc anomaly first: ea */
    double ea = 2.*atan(tan(0.5*nu)*zi);
    /* mn: mean anomaly */
    mn = ea - e*sin(ea);
 } else if(e > 1.0){                /* hyperbolic */
    double zi = sqrt((e-1.)/(e+1.));
    /* calc hyp anomaly first: ha */
    double ha = 2.*atanh(tan(0.5*nu)*zi); /* atan hyperbolic ! */
    /* mn: mean anomaly */
    mn = -ha + e*sinh(ha);
    mn = fwraptopi_mod(mn);
 } else {                           /* parabolic */
    /* rare case. Barker's equation may yield
       jumps across e = 1. => set mn to zero ? */
    /*
    double hp = tan(0.5*nu);
    mn = hp + hp*hp*hp/3.;
    mn = fwraptopi_mod(mn);
    */
    mn = 0.;
 }
 return(mn);
}
/*============================================================*/
/*============================================================*/
/*
  acos_r() restrict output: nan -> PI, 0
*/
double acos_r(double x)
{
 double y=0.;
 if(fabs(x) < 1.){
     y = acos(x);
 } else {
     if(x <= -1.) y = PI;
     if(x >=  1.) y = 0.; 
 }
 return(y);
}
/*============================================================*/
/*======== fget_eccvec() & fmean_anomaly() & acos_r() END ====*/
/*============================================================*/

/*============================================================*/
/*===================== fxv2elm() ============================*/
/*============================================================*/
/*
  Input = body coords. Output = orbital elements

  !!! FOR ACCURACY AND STORAGE DO NOT USE ELEMENTS !!!
  !!! USE STATE VECTORS X V                        !!!

  For small or zero values of inclination and/or eccentricity, 
  the cases below mostly avoid NaN output (elements may not be 
  accurate in those cases!) 
  
  If output shows errors, try to raise ECC_SMALL, INC_SMALL
  (see below)

  ecc/inc cases: all for 0 <= e < 1 (circ / elliptic)
  TABLE NOTE: ">0" means >X_SMALL. "=0" means <=X_SMALL
  ============================================================
  ecc      inc    om(ArgP)   Om(LAN)   vpi(LonP)   M(MeanAn)
  ------------------------------------------------------------
  e>0      i>0    OK         OK        OK Om+om    OK
  e>0      i=0    OK         undef     = om        OK
  e=0      i>0    undef      OK        = Om        angle n-r
  e=0      i=0    undef      undef     undef       angle xaxis-r
  ============================================================
*/
#define ECC_SMALL 1.*DBL_EPS /* e_s */
#define INC_SMALL 1.*DBL_EPS /* i_s */
//#define ECC_SMALL 1.e-14 /* e_s */
//#define INC_SMALL 1.e-14 /* i_s */

#define E_NORM_I_NORM 1 /* e_s  < e < 1 && i >  i_s */
#define E_NORM_I_SMLL 2 /* e_s  < e < 1 && i <= i_s */
#define E_SMLL_I_NORM 3 /* e   <= e_s   && i >  i_s */
#define E_SMLL_I_SMLL 4 /* e   <= e_s   && i <= i_s */
/*============================================================*/
void fxv2elm(struct elements *elm, double *x, double *v, 
             double eta0)
{
 const double eta0i = 1./eta0;
 double hv[CDIM],h,r,ri,p,xv,ev[CDIM],ee,er,nu;
 double n0[CDIM] = {NAN, 0., 0., 1.};
 double nv[CDIM],nn,ne,nr;
 char mssg[BUFSIZ];
 int ei_case = 0;
 double *a   = &elm->a;   /* semimajor axis */
 double *e   = &elm->e;   /* eccentricity   */
 double *inc = &elm->i;   /* inclination    */
 double *om  = &elm->om;  /* ArgPerihelion  */
 double *oom = &elm->oom; /* LongAscNode    */
 double *vpi = &elm->vpi; /* LongPerihelion */
 double *mn  = &elm->mn;  /* mean anomaly   */

 vcross(hv,x,v);
 h  = NORM(hv);
 r  = NORM(x);
 ri = 1./r;
 p  = h*h*eta0i;
 xv = vvdot(x,v,3);
 double z1 = p*ri - 1.;
 double z2 = h*xv*eta0i*ri;
 
 /* e: eccentricity */
 *e = sqrt(z1*z1 + z2*z2);

 /* a, inc: semimajor axis, inclination */
 if(fabs(*e-1.) > DBL_EPS){
    *a = p/(1.-(*e)*(*e)); /* elliptical & hyperbolic */
 } else {
    *a = 1./DBL_EPS;       /* parabolic */
 }
 *inc = acos(hv[3]/h);

 /* ecc/inc: set ei-case */
 if(fabs(*e) > ECC_SMALL){
    if(*inc > INC_SMALL && (PI-*inc) > INC_SMALL) 
         ei_case = E_NORM_I_NORM; // 1
    else ei_case = E_NORM_I_SMLL; // 2
 } else {
    if(*inc > INC_SMALL && (PI-*inc) > INC_SMALL) 
         ei_case = E_SMLL_I_NORM; // 3
    else ei_case = E_SMLL_I_SMLL; // 4 
 }

 switch(ei_case)
  {
   /*===================================================*/
   case E_NORM_I_NORM: // 1
   
        /* calculate ecc vector ev, norm ee */
        fget_eccvec(ev,&ee,x,v,hv,ri,eta0i); // *e-ee ~= eps
        /* calculate n-vec (points to node) and nv dot ev */
        vcross(nv,n0,hv);
        nn = NORM(nv);
        ne = vvdot(nv,ev,3);
        /* om: ArgPerihelion [0 2PI] */
        *om = acos_r(ne/(nn*ee));
        if(ev[3] < 0.)
          *om = 2.*PI - *om;
        /* oom: LongAscNode [-PI PI] */
        *oom = atan2(hv[1],-hv[2]);
        /* vpi: LongPerihelion */
        *vpi = *oom + *om;
        /* wrap om, vpi to [-PI PI] */
        *om  = fwraptopi(*om);
        *vpi = fwraptopi(*vpi);
        /* calc true anomaly first: nu */
        er = vvdot(ev,x,3);
        nu = acos_r(er/(ee*r));
        if(xv < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(ee,nu);

        break;
   /*===================================================*/
   case E_NORM_I_SMLL: // 2

        /* calculate ecc vector ev, norm ee */
        fget_eccvec(ev,&ee,x,v,hv,ri,eta0i); // *e-ee ~= eps
        /* oom: LongAscNode set to zero */
        *oom = 0.;
        /* om: ArgPerihelion (angle xaxis-ecc vector) [-PI PI] */
        *om = atan2(ev[2],ev[1]);
        /* vpi: LongPerihelion */
        *vpi = *om;
        /* calc true anomaly first: nu */
        er = vvdot(ev,x,3);
        nu = acos_r(er/(ee*r));
        if(xv < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(ee,nu);

        break;      
   /*===================================================*/
   case E_SMLL_I_NORM: // 3

        /* calculate n-vec (points to node) and nv dot ev */
        vcross(nv,n0,hv);
        nn = NORM(nv);
        /* oom: LongAscNode [-PI PI] */
        *oom = atan2(hv[1],-hv[2]);
        /* om: ArgPerihelion set to zero */
        *om = 0.;
        /* vpi: LongPerihelion */
        *vpi = *oom;
        /* calc true anomaly first: nu */        
        /* true anomaly here: angle n-r */
        nr = vvdot(nv,x,3);
        nu = acos_r(nr/(nn*r));
        if(x[3] < 0.)
           nu = 2.*PI - nu;
        /* mn: mean anomaly */
        *mn = fmean_anomaly(*e,nu); // *e NOT ee

        break;
   /*===================================================*/
   case E_SMLL_I_SMLL: // 4

        /* oom: LongAscNode set to zero    */
        *oom = 0.;
        /* om: ArgPerihelion set to zero   */
        *om  = 0.;
        /* vpi: LongPerihelion set to zero */
        *vpi = 0.;
        /* calc true anomaly first: nu */
        /* true anomaly here: angle xaxis-r */
        nu = atan2(x[2],x[1]);
        /* mn: mean anomaly */
        *mn = fmean_anomaly(*e,nu); // *e NOT ee

        break;
   /*===================================================*/
   default:
        sprintf(mssg,"fxv2elm(): ei_case failed. e = %e inc = %e",*e,*inc);
        ferrx(mssg);
 }

#ifdef _ANG_DEG_
 *inc = *inc*R2D;
 *om  =  *om*R2D;
 *oom = *oom*R2D;
 *vpi = *vpi*R2D;
 *mn  =  *mn*R2D;
#endif

}
/*============================================================*/
/*===================== fxv2elm() END ========================*/
/*============================================================*/

/*============================================================*/
/*===================== freadXVwrtElm() ======================*/
/*============================================================*/
/*
  read orbitN output x v, write Keplerian elements.
*/
void freadXVwrtElm()
{
 int j;
 double t;
 struct elements elm;
 FILE *freadj[J+1],*fporbj[J+1];
 char str[BUFSIZ],fnreadj[BUFSIZ],fnorbj[BUFSIZ],mssg[2*BUFSIZ];
 char ff[BUFSIZ]="%.15g %24.16e %24.16e %24.16e %24.16e %24.16e %24.16e %24.16e\n";

 double *m, *x, *v;
 m = dvector(0,J);
 x = dvector(1,3);
 v = dvector(1,3);

#if _ELM_MJ_ == 1
  /* read initial coordinates. set dir & file */
 double **xx, **vv;
 char dir[BUFSIZ],foo[BUFSIZ];
 /* include index zero = central mass */
 xx = dmatrix(0,J,1,3);
 vv = dmatrix(0,J,1,3);
 strcpy(dir,INNDIR);
 strcpy(foo,"orbitN-coord.inp");
 freadcoords(dir,foo,J,m,xx,vv); 
#else
 for(j=0;j<=J;j++)
     m[j] = 0.;
#endif

 /* Input body coords: central mass */
 m[0] = M0;

 /* output elements (body): exclude index 0 */
 int jstart = 1;

 /* read: open files */	
 for(j=jstart;j<=J;j++){
     sprintf(fnreadj,"%s/%s%d.%s",INNDIR,INNFILE,j,INN_EXT);
     printf("@ Orbit file to be read = '%s'\n",fnreadj);     
     freadj[j] = fopen(fnreadj,"r");
     if(freadj[j] == NULL){ 
        sprintf(mssg,"@ Can't open file: '%s'",fnreadj);
        ferrx(mssg);
     }
 }
 printf("\n");

 /* write: open files */
 for(j=jstart;j<=J;j++){
     sprintf(fnorbj,"%s/%s%d.%s",OUTDIR,OUTFILE,j,OUT_EXT);
     printf("@ Orbit file to be written = '%s'\n",fnorbj);
     fporbj[j] = fopen(fnorbj,"w");
     if(fporbj[j] == NULL){
        sprintf(mssg,"@ Can't open file: '%s'",fnreadj);
        ferrx(mssg);
     }
 }
 printf("\n");

 /* read & write files */
 for(j=jstart;j<=J;j++){
     printf("@ Reading & writing j = %d \n",j);
     while(fgets(str,BUFSIZ,freadj[j]) != NULL){
       /* read */
       sscanf(str,"%lf %lf %lf %lf %lf %lf %lf", \
              &t,&x[1],&x[2],&x[3], \
                 &v[1],&v[2],&v[3]);
       const double eta0 = (m[0]+m[j]*_ELM_MJ_)*(KGAUSS*KGAUSS);
       /* convert to elements */
       fxv2elm(&elm,x,v,eta0);
       /* write */
       fprintf(fporbj[j],ff,t, \
               elm.a,elm.e,elm.i,elm.om,elm.oom,elm.vpi,elm.mn);
     }
 }
 printf("\n@ xv2elm Done.\n"); 

 /* close files */
 for(j=jstart;j<=J;j++){
     fclose(freadj[j]);
     fclose(fporbj[j]);
 }

 free_dvector(m,0,J);
 free_dvector(x,1,3);
 free_dvector(v,1,3);
#if _ELM_MJ_ == 1
 free_dmatrix(xx,0,J,1,3);
 free_dmatrix(vv,0,J,1,3);
#endif

}
/*============================================================*/
/*===================== freadXVwrtElm() END ==================*/
/*============================================================*/

/*============================================================*/
/*==================== int main() ============================*/
/*============================================================*/
int main(int argc, char **argv)
{
 UNUSED(argc); UNUSED(argv);
 
 freadXVwrtElm();

 return(0);
}
/*==================== int main END ==========================*/
