/***************************************************************

   orbitN VERSION: 1.0.0 (05/2023)
   file: utils.c

   *** orbitN comes with ABSOLUTELY NO WARRANTY ***
   *** Use at your own risk. DO NOT DISTRIBUTE  ***
   *** except under GNU General Public License  ***

   Richard E. Zeebe
   University of Hawaii at Manoa
   1000 Pope Road, MSB 629
   Honolulu, HI 96822, USA
   correspondence to: 
   orbitN.code@gmail.com
                             ___  ___  ___

   Copyright (c) 2023 Richard E. Zeebe
   This file is part of orbitN

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 3.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
                             ___  ___  ___

   based on nrutils.c, parts from Numerical Recipes in C.
   additions at the end

   updates:

   03/04/23

   TODO:

***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include "utils.h"
#include "orbitN.h"

#define NR_END 1
#define FREE_ARG char*

void nrerror(char error_text[])
/* NR standard error handler */
{
    fflush(stdout);
    fflush(stderr);	
	fprintf(stderr,"NR run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	exit(1);
}

int *ivector(long nl, long nh)
/* allocate an int vector with subscript range v[nl..nh] */
{
	int *v;
	
    v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl+NR_END;
}

double *dvector(long nl, long nh)
/* allocate a double vector with subscript range v[nl..nh] */
{
	double *v;

	v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl+NR_END;
}

double **dmatrix(long nrl, long nrh, long ncl, long nch)
/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	double **m;

	/* allocate pointers to rows */
	m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double*)));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m += NR_END;
	m -= nrl;

	/* allocate rows and set pointers to them */
	m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double)));
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
	m[nrl] += NR_END;
	m[nrl] -= ncl;

	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

	/* return pointer to array of pointers to rows */
	return m;
}

int **imatrix(long nrl, long nrh, long ncl, long nch)
/* allocate a int matrix with subscript range m[nrl..nrh][ncl..nch] */
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	int **m;

	/* allocate pointers to rows */
	m=(int **) malloc((size_t)((nrow+NR_END)*sizeof(int*)));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m += NR_END;
	m -= nrl;


	/* allocate rows and set pointers to them */
	m[nrl]=(int *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(int)));
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
	m[nrl] += NR_END;
	m[nrl] -= ncl;

	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

	/* return pointer to array of pointers to rows */
	return m;
}

double ***d3tensor(long nrl, long nrh, long ncl, long nch, long ndl, 
                   long ndh)
/* allocate a double 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */
{
	long i,j,nrow=nrh-nrl+1,ncol=nch-ncl+1,ndep=ndh-ndl+1;
	double ***t;

	/* allocate pointers to pointers to rows */
	t=(double ***) malloc((size_t)((nrow+NR_END)*sizeof(double**)));
	if (!t) nrerror("allocation failure 1 in f3tensor()");
	t += NR_END;
	t -= nrl;

	/* allocate pointers to rows and set pointers to them */
	t[nrl]=(double **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double*)));
	if (!t[nrl]) nrerror("allocation failure 2 in f3tensor()");
	t[nrl] += NR_END;
	t[nrl] -= ncl;

	/* allocate rows and set pointers to them */
	t[nrl][ncl]=(double *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(double)));
	if (!t[nrl][ncl]) nrerror("allocation failure 3 in f3tensor()");
	t[nrl][ncl] += NR_END;
	t[nrl][ncl] -= ndl;

	for(j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
	for(i=nrl+1;i<=nrh;i++) {
		t[i]=t[i-1]+ncol;
		t[i][ncl]=t[i-1][ncl]+ncol*ndep;
		for(j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1]+ndep;
	}

	/* return pointer to array of pointers to rows */
	return t;
}

void free_ivector(int *v, long nl, long nh)
/* free an int vector allocated with ivector() */
{
	free((FREE_ARG) (v+nl-NR_END));
	if(nh < nl) nrerror("free_ivector(): nh < nl");
}

void free_dvector(double *v, long nl, long nh)
/* free a double vector allocated with dvector() */
{
	free((FREE_ARG) (v+nl-NR_END));
	if(nh < nl) nrerror("free_dvector(): nh < nl");
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
/* free a double matrix allocated by dmatrix() */
{
	free((FREE_ARG) (m[nrl]+ncl-NR_END));
	free((FREE_ARG) (m+nrl-NR_END));
	if(nrh < nrl) nrerror("free_dmatrix(): nrh < nrl");
	if(nch < ncl) nrerror("free_dmatrix(): nch < ncl");	
}

void free_imatrix(int **m,long nrl,long nrh,long ncl,long nch)
/* free an int matrix allocated by imatrix() */
{
	free((FREE_ARG) (m[nrl]+ncl-NR_END));
	free((FREE_ARG) (m+nrl-NR_END));
	if(nrh < nrl) nrerror("free_imatrix(): nrh < nrl");
	if(nch < ncl) nrerror("free_imatrix(): nch < ncl");	
}

void free_d3tensor(double ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh)
/* free a double f3tensor allocated by f3tensor() */
{
	free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
	free((FREE_ARG) (t[nrl]+ncl-NR_END));
	free((FREE_ARG) (t+nrl-NR_END));
	if(nrh < nrl) nrerror("free_d3tensor(): nrh < nrl");
	if(nch < ncl) nrerror("free_d3tensor(): nch < ncl");	
	if(ndh < ndl) nrerror("free_d3tensor(): ndh < ndl");	
}

/*===================== REZ additions ================*/

 /* error output */
 void ferrx(char error_text[])
 {
    fflush(stdout);
    fflush(stderr);	 
	fprintf(stderr,"\n");
	fprintf(stderr,"@ ======================== Error.\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"@ ====================== Exiting.\n");
	exit(1);
 }

 /* warning */
 void fwarn(char warn_text[])
 {
    fflush(stdout);
    fflush(stderr);
	fprintf(stderr,"\n");
	fprintf(stderr,"@ ======================== Warning.\n");
	fprintf(stderr,"%s\n",warn_text);
	fprintf(stderr,"@ ===================== Continuing.\n");
    fflush(stderr);
 }

 /****** intmin: min of 2 ints, returns int **********/
 int intmin(int a, int b) {
    if (a > b)
        return b;
    return a;
 }

 /****** vsclr: vector X scalar, returns vector ******/
 void vsclr(double *w,double s,double *u,int n)
 {
  int i;
 
  for(i=1;i<=n;i++)
    w[i] = s*u[i];
 }

 /****** vvdot: vector product, returns scalar *******/
 double vvdot(double *u,double *v,int n)
 {
  int i;
  double s=0.0;

  for(i=1;i<=n;i++)
    s += u[i]*v[i];

  return(s);	 
 }

 /****** vcross: vector cross product, returns vector *******/
 void vcross(double *w,double *u,double *v)
 {
  w[1] = u[2]*v[3]-u[3]*v[2];
  w[2] = u[3]*v[1]-u[1]*v[3];
  w[3] = u[1]*v[2]-u[2]*v[1];	
 }

 /*** vsumlh: sum vector elements, returns scalar **/
 double vsumlh(double *u,int n,int nl,int nh)
 {
  int i;
  double s;

  if(nh > n)
     ferrx("vsumlh(): nh exceeds vector length n.");
	 
  s = 0.;
  for(i=nl;i<=nh;i++)
    s += u[i];

  return(s);	 
 }

 /*** msumlh: sum matrix column elements, returns scalar **/
 double msumlh(double **m,int krmax,int k,int n,int nl,int nh)
 {
 /* k = row, n: column */	 
  int i;
  double s;

  if(k > krmax)
     ferrx("msumlh(): k exceeds matrix row length krmax.");
  if(nh > n)
     ferrx("msumlh(): nh exceeds matrix column length n.");
	 
  s = 0.;
  for(i=nl;i<=nh;i++)
    s += m[k][i];

  return(s);	 	 
 }

 /****** vvsum: vector sum, returns vector *******/
 void vvsum(double *w,double *u,double *v,int n)
 {
  int i;

  for(i=1;i<=n;i++)
    w[i] = u[i] + v[i];
 }

 /****** vvsub: vector subtraction, returns vector *******/
 void vvsub(double *w,double *u,double *v,int n)
 {
  int i;

  for(i=1;i<=n;i++)
    w[i] = u[i] - v[i];
 }

 /****** vvelm: v-elmnt X v-elmnt, returns vector *******/
 void vvelm(double *w,double *u,double *v, int n)
 {
  int i;

  for(i=1;i<=n;i++)
    w[i] = u[i]*v[i];
 }

 /****** vdelm: v-elmnt / v-elmnt, returns vector *******/
 void vdelm(double *w,double *u,double *v, int n)
 {
  int i;

  for(i=1;i<=n;i++)
    w[i] = u[i]/v[i];
 }

 /*** fsetiv: init int vector elements , returns vector ******/
 void fsetiv(int *iv,int k,int n)
 {
  int i;

  for(i=1;i<=n;i++)
    iv[i] = k;
 }

 /*** fsetv: init double vector elements , returns vector ******/
 void fsetv(double *u,double x,int n)
 {
  int i;

  for(i=1;i<=n;i++)
    u[i] = x;
 }

 /*** fvec2arr: store 2 vectors in matrix, returns matrix ******/
 void fvec2arr(double **m,double *x,double *y,int n)
 {
  int i;

  for(i=1;i<=n;i++){
       m[i][1] = x[i];
       m[i][2] = y[i];
  }		
 } 

/*** ftransp: transpose 3x3 = [a1[3] a2[3] a3[3]] ******/
void ftransp(double *a1,double *a2,double *a3)
 {
  int i;
  double b1[4],b2[4],b3[4];

  /* make copy */
  for(i=1;i<=3;i++){
	b1[i] = a1[i];
	b2[i] = a2[i];
	b3[i] = a3[i];
  }
  /* swap elements */
  a1[2] = b2[1];
  a1[3] = b3[1];
  a2[1] = b1[2];
  a2[3] = b3[2];
  a3[1] = b1[3];
  a3[2] = b2[3];
 } 

/*** fcopyx: make copy of x array => xc ******/
void fcopyx(double **xc, double **x, const int jmax)
 {
 int j;

 /* index from 0=central mass to jmax=J */
 for(j=0;j<=jmax;j++){
    xc[j][1] = x[j][1];
    xc[j][2] = x[j][2];
    xc[j][3] = x[j][3];
 }  
 }

/*** fcopy_x: make copy of x array => xc[][] ******/
void fcopy_x(double xc[][CDIM], double **x, const int jmax)
 {
 int j;

 /* index from 0=central mass to jmax=J */
 for(j=0;j<=jmax;j++){
    xc[j][1] = x[j][1];
    xc[j][2] = x[j][2];
    xc[j][3] = x[j][3];
 }  
 }

/*** fcopyxv: make copy of x v arrays => xc vc ******/
void fcopyxv(double **xc, double **vc, double **x, 
              double **v, const int jmax)
 {
 int j;

 /* index from 0=central mass to jmax=J */
 for(j=0;j<=jmax;j++){
    xc[j][1] = x[j][1];
    xc[j][2] = x[j][2];
    xc[j][3] = x[j][3];
    vc[j][1] = v[j][1];
    vc[j][2] = v[j][2];
    vc[j][3] = v[j][3];
  }

 }

/*** fcopyxv_khn: make copy of x v arrays, add dx dv => xc vc ******/
void fcopyxv_khn(double **xc, double **vc, double **x, 
             double **v, double **dx, double **dv, 
             const int jmax)
 {
 int j;

 /* index from 0=central mass to jmax=J */
 for(j=0;j<=jmax;j++){
    xc[j][1] = x[j][1] + dx[j][1];
    xc[j][2] = x[j][2] + dx[j][2];
    xc[j][3] = x[j][3] + dx[j][3];
    vc[j][1] = v[j][1] + dv[j][1];
    vc[j][2] = v[j][2] + dv[j][2];
    vc[j][3] = v[j][3] + dv[j][3];
  }

 }

 /*** fwraptopi: simple wrap to [-PI PI]. -3PI <= x <= 3PI ***/
 double fwraptopi(double x)
 {
  const double twopi = 2.*PI; 
  if(x >  PI){
     return(x - twopi);
  } else
  if(x < -PI){
     return(x + twopi);
  }
  else{
     return(x);
  }
 
 }

 /*** fwraptopi_mod: wrap to [-PI PI] using fmod() ***/
 double fwraptopi_mod(double x)
 {
  double y = fmod(x + PI, 2*PI);
  return y >= 0 ? (y - PI) : (y + PI);
 }
